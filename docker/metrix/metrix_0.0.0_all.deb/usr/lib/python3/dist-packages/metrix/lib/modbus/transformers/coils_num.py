from .coil import CoilTransformer
from .abstract_chain import AbstractChainTransformer
from metrix.schema import validation
from schema import Optional, And

from .register import RegisterTransformer
from .input_register import InputRegisterTransformer
from ..utils import default

class CoilsNumTransformer(AbstractChainTransformer):
    def __init__(self, config):
        self.count = config["count"]
        self.revert = config["revert"] if "revert" in config else False
        self.chain = CoilTransformer({"count": self.count})

    def tr_read(self, value):
        if not self.revert:
            value = value[::-1]
        num = 0
        for bit in value:
            num = (num * 2) + (1 if bit else 0)

        return num

    def tr_write(self, value):
        bits = []
        for i in range(self.count):
            bits.append(True if ((value % 2) != 0) else False)
            value = value // 2
        if self.revert:
            bits = bits[::-1]
        return bits


    validation = {
        "count": And(int, validation.range(0, 32)),
        Optional("revert"): bool,
    }
