import time, asyncio
from metrix import client, message_type, validate, validation, logger
from metrix.lib.scheduler import Scheduler
from schema import And, Or, Optional

COMMANDS_VALIDATION = {
    "add": {
        Optional("id"): Or(None, validation.identifier),
        "topic": validation.topic,
        Optional("interval"): Or(int, float),
        Optional("start_at"): Or(None, int, float),
        Optional("repeat"): Or(None, bool),
    },
    "remove": {
        "id": validation.identifier,
    }
}

MESSAGE_VALIDATION = validation.polymorphic("command", COMMANDS_VALIDATION)

runtime = {}

def do_invoke(topic):
    client.message(topic, {})

def process_add(command):
    if "write_mode" not in command or command["write_mode"] is None:
        command["write_mode"] = "w"
    
    id = command["id"] if "id" in command else None
    topic = command["topic"]
    interval = command["interval"] if "interval" in command else None
    start_at = command["start_at"] if "start_at" in command else None
    repeat = command["repeat"] if "repeat" in command else False
    repeat = True if repeat else False

    handle = runtime["scheduler"].schedule(
        interval=interval,
        at=start_at,
        repeat=repeat,
        callback=lambda: do_invoke(topic)
    )

    if id is not None:
        runtime["handles"][id] = handle
    
    return True

def process_remove(command):
    id = command["id"]
    if id not in runtime["handles"]:
        raise Exception(f"cannot remove timer {command['id']}, given id does not exist")
    runtime["handles"][id].remove()
    del runtime["handles"][id]
    return True

COMMANDS = {
    "add": process_add,
    "remove": process_remove,
}

def process_command(command):
    cmd = command["command"]
    if cmd not in COMMANDS:
        return False
    try:
        return COMMANDS[cmd](command)
    except KeyboardInterrupt:
        raise
    except Exception as e:
        logger(f"cannot invoke {cmd}: {e}", lev = logger.WARN)
        # command was accepted even if it failed
        # the error message was already displayed and therefore
        # we return True suppressing the default error message
        return True


def metrix_init():
    runtime["topic"] = client.get_config("control_topic", "_timer", validation.topic)
    runtime["scheduler"] = Scheduler()
    runtime["handles"] = {}
    client.listen(message_type.MESSAGE, runtime["topic"])

def metrix_loop():
    timeout = runtime["scheduler"].loop(6000)
    client.schedule_loop(timeout=timeout, wake_on_msg=True, oneshot=True)

def metrix_recv(msg):
    if msg.has_type(message_type.MESSAGE) and msg.has_topic(runtime["topic"]):
        if not msg.check_payload(MESSAGE_VALIDATION) or not process_command(msg.payload):
            logger(f"got invalid command: {msg.payload_as_string()}", lev=logger.WARN)
