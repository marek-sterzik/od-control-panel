class AbstractModbusDriver:
    async def init(self):
        pass
    async def quit(self):
        pass

    async def read_coil(self, device, addr):
        ret = await self.read_coil_multi(device, addr, 1)
        return ret[0]
    async def read_coil_multi(self, device, addr, count):
        raise Exception("reading coils not implemented")
    async def write_coil(self, device, addr, value):
        await self.write_coil_multi(device, addr, [value])
    async def write_coil_multi(self, device, addr, values):
        raise Exception("writing coil not implemented")

    async def read_reg(self, device, addr):
        ret = await self.read_reg_multi(device, addr, 1)
        return ret[0]
    async def read_reg_multi(self, device, addr, count):
        raise Exception("reading registers not implemented")
    async def write_reg(self, device, addr, value):
        await self.write_reg_multi(device, addr, [value])
    async def write_reg_multi(self, device, addr, values):
        raise Exception("writing register not implemented")

    async def read_di(self, device, addr):
        ret = await self.read_di_multi(device, addr, 1)
        return ret[0]
    async def read_di_multi(self, device, addr, count):
        raise Exception("reading discrete inputs not implemented")
    async def write_di(self, device, addr, value):
        await self.write_di_multi(device, addr, [value])
    async def write_di_multi(self, device, addr, values):
        raise Exception("writing discrete inputs not implemented")
    
    async def read_ireg(self, device, addr):
        ret = await self.read_ireg_multi(device, addr, 1)
        return ret[0]
    async def read_ireg_multi(self, device, addr, count):
        raise Exception("reading input registers not implemented")
    async def write_ireg(self, device, addr, value):
        await self.write_ireg_multi(device, addr, [value])
    async def write_ireg_multi(self, device, addr, values):
        raise Exception("writing input register not implemented")

