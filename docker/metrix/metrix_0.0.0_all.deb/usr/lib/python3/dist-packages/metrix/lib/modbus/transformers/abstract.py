class AbstractTransformer:
    def get_read_operation(self):
        raise Exception("get_read_operation method is abstract")

    def read_transform(self, value):
        return value

    def write_transform(self, value):
        return value

    def get_write_operation(self, value):
        raise Exception("get_write_operation method is abstract")

