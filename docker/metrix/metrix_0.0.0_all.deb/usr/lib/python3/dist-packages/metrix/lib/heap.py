

class HeapException(RuntimeError):
    pass

def _parent(index):
    return (index - 1) // 2

def _son1(index):
    return 2*index + 1


class HeapItem:
    def val(self):
        return self

class DefaultHeapItem(HeapItem):
    def __init__(self, value):
        self.value = value

    def val(self):
        return self.value

def _get_heap_item(obj):
    if isinstance(obj, HeapItem):
        return obj
    return DefaultHeapItem(obj)

class Heap:
    def __init__(self, comparator):
        self.comparator = comparator
        self.heap = []
        self.indices = {}

    def empty(self):
        return len(self.heap) == 0

    def find_first(self):
        if self.empty():
            raise HeapException("heap is empty")
        return self.heap[0]

    def delete_first(self):
        item = self.find_first()
        self._delete_by_index(0)
        return item

    def delete(self, item):
        if not isinstance(item, HeapItem):
            raise HeapException(f"only objects of type {HeapItem.__name__} can be deleted")
        if item not in self.indices:
            raise HeapException("item not in heap")
        index = self.indices[item]
        self._delete_by_index(index)
        return item

    def add(self, item):
        item = _get_heap_item(item)
        if item in self.indices:
            raise HeapException("item already in heap")
        index = len(self.heap)
        self.heap.append(item)
        self.indices[item] = index
        self._bubble_up(index)
        return item

    def update(self, item):
        if not isinstance(item, HeapItem):
            raise HeapException(f"only objects of type {HeapItem.__name__} can be update")
        if item not in self.indices:
            raise HeapException("item not in heap")
        index = self.indices[item]
        self._restruct(index)
        return item

    def _restruct(self, index):
        if index < 0 or index >= len(self.heap):
            raise HeapException("heap index out of range")
        if index > 0 and self.comparator(self.heap[_parent(index)].val(), self.heap[index].val()) > 0:
            self._bubble_up(index)
        else:
            self._bubble_down(index)

    def _delete_by_index(self, index):
        l = len(self.heap)
        if index < 0 or index >= l:
            raise HeapException("heap index out of range")
        removed_item = self.heap[index]
        del self.indices[removed_item]
        if index + 1 < l:
            self.heap[index] = self.heap[l - 1]
            self.indices[self.heap[index]] = index
        self.heap.pop()
        if index + 1 < l:
            self._restruct(index)
        return removed_item

    def _bubble_up(self, index):
        while index > 0 and self.comparator(self.heap[_parent(index)].val(), self.heap[index].val()) > 0:
            self._swap_with_parent(index)
            index = _parent(index)

    def _bubble_down(self, index):
        l = len(self.heap)
        while _son1(index) < l:
            s1 = _son1(index)
            s2 = s1 + 1
            if s2 < l and self.comparator(self.heap[s2].val(), self.heap[s1].val()) < 0:
                s = s2
            else:
                s = s1
            if self.comparator(self.heap[index].val(), self.heap[s].val()) <= 0:
                break
            index = s
            self._swap_with_parent(index)

    def _swap_with_parent(self, index):
        if index > 0:
            parent = _parent(index)
            (self.heap[index], self.heap[parent]) = (self.heap[parent], self.heap[index])
            self.indices[self.heap[index]] = index
            self.indices[self.heap[parent]] = parent

