from .topic_lookup import type_topic_lookup
from .random_id import random_id
from .message_type import message_type
from .message import message
from .process_state import process_state
from .attrdict import attrdict
from .routed_message import RoutedMessage

trigger_state = attrdict()
trigger_state["WAITING"] = "waiting"
trigger_state["RUNNING"] = "running"
trigger_state["SHUTTING_DOWN"] = "shutting_down"

class TriggerDescriptor:
    def __init__(self):
        self.module = None
        self.arguments = []
        self.libs = []
        self.triggers = []
        self.trigger_id = None

    def set_module(self, module):
        self.module = module
        return self

    def set_arguments(self, arguments):
        self.arguments = arguments
        return self

    def set_libs(self, libs):
        self.libs = libs

    def add_trigger(self, topic, msg_types):
        self.triggers.append({"topic": topic, "msg_types": msg_types})
        return self

    def set_id(self, id):
        self.trigger_id = id

    def validate(self):
        if self.module is None:
            raise Exception("missing module")
        for t in self.triggers:
            for msg_type in t["msg_types"]:
                if msg_type not in [message_type.BROADCAST, message_type.QUERY, message_type.WRITE, message_type.ERROR, message_type.MESSAGE]:
                    raise Exception(f"cannot add trigger for message type: '{msg_type}'")

class Trigger:
    def __init__(self, module, arguments, libs):
        self.pid = None
        self.state = trigger_state.WAITING
        self.msg_queue = []
        self.module = module
        self.arguments = arguments
        self.libs = libs

    def update_state(self, pstate):
        if pstate in [process_state.CREATED, process_state.CONFIGURING]:
            self.state = trigger_state.WAITING
        elif pstate == process_state.RUNNING:
            self.state = trigger_state.RUNNING
        else:
            self.state = trigger_state.SHUTTING_DOWN

    def get_message(self):
        msg = None
        if len(self.msg_queue) > 0:
            msg = self.msg_queue[0]
            self.msg_queue = self.msg_queue[1:]
        return msg

    async def start(self, server):
        msg = message(message_type.CORE, "start", {"module": self.module, "args": self.arguments, "pid": self.pid, "libs": self.libs})
        await server.handle_external_message(msg)
            
        

class Triggers:
    def __init__(self, server):
        self.server = server
        self.tt_lookup = type_topic_lookup()
        self.pid_lookup = {}
        self.id_lookup = {}

    def add_trigger(self, trigger_descriptor):
        trigger_descriptor.validate()
        if trigger_descriptor.trigger_id is not None and trigger_descriptor.trigger_id in self.id_lookup:
            raise Exception(f"cannot add trigger with trigger id '{trigger_descriptor.trigger_id}', trigger already exists")
        trigger = Trigger(trigger_descriptor.module, trigger_descriptor.arguments, trigger_descriptor.libs)
        for t in trigger_descriptor.triggers:
            topic = t["topic"]
            for msg_type in t["msg_types"]:
                self.tt_lookup.add(msg_type, topic, trigger)
        if trigger_descriptor.trigger_id is not None:
            self.id_lookup[trigger_descriptor.trigger_id] = trigger

    def remove_trigger(self, trigger_id):
        if trigger_id is None or trigger_id not in self.id_lookup:
            raise Exception(f"cannot remove trigger with id '{trigger_id}', trigger does not exist")
        trigger = self.id_lookup[trigger_id]
        del self.id_lookup[trigger_id]
        self.tt_lookup.remove_all(trigger)

    async def consume_message(self, msg):
        if msg.msg_type == message_type.PROCESS:
            pid = msg.topic
            pstate = msg.payload
            if pid in self.pid_lookup:
                trigger = self.pid_lookup[pid]
                trigger.update_state(pstate)
                if trigger.state == trigger_state.RUNNING:
                    msg = trigger.get_message()
                    while msg is not None:
                        await self.send_message_to_pid(msg, pid)
                        if trigger.state != trigger_state.RUNNING:
                            break
                        msg = trigger.get_message()
                elif trigger.state == trigger_state.SHUTTING_DOWN:
                    if len(trigger.msg_queue) > 0:
                        await self.reset_pid(trigger)
            return []
            
        pids = []
        for trigger in self.tt_lookup.get_objects(msg.msg_type, msg.topic):
            if await self.process_trigger(trigger, msg):
                pids.append(trigger.pid)
        return pids

    async def reset_pid(self, trigger):
        if (trigger.pid is None) or (trigger.state == trigger_state.SHUTTING_DOWN):
            if trigger.pid is not None:
                del self.pid_lookup[trigger.pid]
                trigger.pid = None
            trigger.pid = random_id("t")
            self.pid_lookup[trigger.pid] = trigger
            trigger.state = trigger_state.WAITING
            await trigger.start(self.server)

    async def process_trigger(self, trigger, msg):
        await self.reset_pid(trigger)
        if trigger.state == trigger_state.RUNNING:
            return False
        trigger.msg_queue.append(msg)
        return True

    async def send_message_to_pid(self, msg, pid):
        await self.server.broadcast_message(RoutedMessage(msg, [], [pid]), None)
            
