import time
from .heap import Heap, HeapItem

class SchedulerHandle:
    def __init__(self, timer, scheduler):
        self.timer = timer
        self.scheduler = scheduler

    def remove(self):
        self.scheduler._remove(self.timer)

class Timer(HeapItem):
    def __init__(self, timestamp, interval, callback):
        self.timestamp = timestamp
        self.interval = interval
        self.callback = callback
        
    def val(self):
        return self.timestamp

    def process(self):
        if self.interval is None:
            return False
        else:
            self.timestamp += self.interval
            while self.timestamp < time.time():
                self.timestamp += self.interval
            return True

    def invoke(self):
        if self.callback is not None:
            self.callback()

class Scheduler:
    def __init__(self):
        self.heap = Heap(lambda a, b: a - b)

    def schedule(self, interval=None, at=None, repeat=False, callback=None):
        if repeat:
            if interval is None:
                raise ValueError("interval must be set on repeated events")
            if interval <= 0:
                raise ValueError("interval must be greater than zero")
            if at is None:
                at = time.time() + interval
            timer = Timer(at, interval, callback)
        elif interval is not None:
            if at is not None:
                raise ValueError("interval and at timestamp cannot be set at the same moment on non-repeated events")
            timer = Timer(time.time() + interval, None, callback)
        else:
            if at is None:
                raise ValueError("either interval or at timestamp must be set on non-repeated events")
            timer = Timer(at, None, callback)
        self.heap.add(timer)
        return SchedulerHandle(timer, self)

    def loop(self, max_timeout = None):
        while self._has_to_process():
            timer = self.heap.find_first()
            if timer.process():
                self.heap.update(timer)
            else:
                self.heap.delete(timer)
            timer.invoke()
        timeout = self._get_next_event_timeout()
        if (max_timeout is not None) and ((timeout is None) or (timeout > max_timeout)):
            timeout = max_timeout
        return timeout

    def _remove(self, timer):
        self.heap.remove(timer)

    def _has_to_process(self):
        next_event_timeout = self._get_next_event_timeout()
        return (next_event_timeout is not None) and (next_event_timeout <=0)

    def _get_next_event_timeout(self):
        if self.heap.empty():
            return None
        return self.heap.find_first().val() - time.time()

