def topic_match(topic, topic_pattern):
    return topic == topic_pattern
