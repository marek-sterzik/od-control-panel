from schema import And, Or, Optional
from metrix.schema import validation
from metrix.lib.devman import devman
from .abstract_pymodbus import AbstractPyModbusDriver
from pymodbus.client import AsyncModbusSerialClient as ModbusClient
from ..utils import default

class PyModbusSerialDriver(AbstractPyModbusDriver):
    def create_client(self, config):
        return ModbusClient(
            port=devman.find(config.get("port"), devman.SERIAL),
            baudrate=config.get("baudrate"),
            bytesize=default(config, "bytesize", 8),
            parity=default(config, "parity", "N"),
            stopbits=default(config, "stopbits", 1),
            timeout=default(config, "timeout", 0.1),
            handle_local_echo=default(config, "handle_local_echo", False),
        )

    validation = {
        "port": str,
        "baudrate": And(int, validation.range(ge=1)),
        Optional("bytesize"): Or(None, And(int, validation.range(7, 8))),
        Optional("parity"): Or(None, validation.enum("E", "O", "N")),
        Optional("stopbits"): Or(None, And(int, validation.range(1, 2))),
        Optional("timeout"): Or(None, And(Or(float, int), validation.range(ge=0))),
        Optional("handle_local_echo"): Or(None, bool),
    }
