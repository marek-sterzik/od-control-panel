from ..process_arguments import parse_process_arguments, get_pid
from ..patchlib import patchlib
import argparse

help="run metrix client process"
aliases=["c"]

def configure(parser):
    parser.add_argument("-p", "--pid", default=None, help="set PID string of the metrix process")
    parser.add_argument("process", nargs="?", help="process module id to be started")
    parser.add_argument("process-arguments", nargs="*", help="process arguments")

def invoke(args):
    patchlib(args.lib)
    pid = None
    if args.pid is not None:
        pid = get_pid(args.pid)
    process = parse_process_arguments(args.process, getattr(args, "process-arguments"))
    if len(process) > 0:
        from ..client import client
        return client.run(module=process[0], server_url=args.url, arguments=process[1:], pid=pid)
    else:
        raise Exception("missing process to start")
