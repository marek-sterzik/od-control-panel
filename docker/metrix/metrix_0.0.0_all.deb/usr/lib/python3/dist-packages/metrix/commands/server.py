from ..process_arguments import parse_process_arguments, arg_from_json
from ..patchlib import patchlib
from ..manifest import load_manifest
from ..schema import check, validation
import os, sys

help="start metrix server"
aliases=["s"]

DEFAULT_MANIFEST_FILE = "metrix.yml"


def configure(parser):
    group = parser.add_mutually_exclusive_group()
    group.add_argument("-b", "--blank", action="store_true", help="start blank server (without processes)")
    parser.add_argument("-p", "--public", action="store_true", help="listen on public IP instead of listening just on localhost")
    parser.add_argument("-P", "--program", default=None, help="invoke the specified program directory (or manifest file)")
    parser.add_argument("-n", "--plugin", default=[], metavar="PLUGIN", action="append", help="manually add plugin to the metrix server")
    parser.add_argument("-e", "--persist", action="store_true", help="persist server even after last process terminates")
    parser.add_argument(
        "-T", "--terminate-timeout", default=None, metavar="TIMEOUT",
        help="set terminate timeout after server quits (wait this time for processes to quit and then terminate)"
    )
    parser.add_argument("process", nargs="?", help="process module id to be started")
    parser.add_argument("process-arguments", nargs="*", help="process arguments")

def split_program(program):
    if os.path.isdir(program):
        return program, None
    if os.path.isfile(program):
        return os.path.dirname(program), program
    if os.path.isdir(os.path.dirname(program)):
        raise Exception("--program must point to an existing manifest file")
    raise Exception("--program must point to an existing directory or to a program manifest file")

def parse_plugins(plugins):
    final_plugins = []
    for plugin in plugins:
        plugin_def = arg_from_json(plugin)
        if not check(validation.plugin, plugin_def):
            raise Exception(f"invalid plugin: {plugin}")
        final_plugins.append(plugin_def)
    return final_plugins

def patch_libs(args, manifest):
    for lib in manifest.libs():
        if lib not in args.lib:
            args.lib.append(lib)

def invoke(args):
    manifest = load_manifest(args.program)
    patch_libs(args, manifest)

    listen_port = args.port
    listen_ip = ["::", "0.0.0.0"] if args.public else "localhost"
    persist = args.persist

    terminate_timeout = args.terminate_timeout
    if terminate_timeout is not None:
        terminate_timeout = float(terminate_timeout)
        if terminate_timeout <= 0:
            raise Exception("terminate timeout must be greater than 0")

    if listen_port is None:
        raise Exception("missing port to start server, use either --port <port> option or --url <url> with a local url")

    process = parse_process_arguments(args.process, getattr(args, "process-arguments"))

    if len(process) > 0:
        if args.blank:
            raise Exception("--blank is incompatible with passing any process to run")
    else:
        if args.blank:
            process = None
        elif manifest.main() is not None:
            process = manifest.main()
        else:
            raise Exception("you must specify a process to run or pass the option --blank")
    
    plugins = parse_plugins(args.plugin) + manifest.plugins()

    from ..server import server
    server.run(
        listen_ip = listen_ip,
        listen_port = listen_port,
        init_process = process,
        plugins = plugins,
        libs = args.lib,
        persist = persist,
        terminate_timeout = terminate_timeout
    )
