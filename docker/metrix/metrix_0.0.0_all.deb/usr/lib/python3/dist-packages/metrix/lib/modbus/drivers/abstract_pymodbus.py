from .abstract import AbstractModbusDriver
import inspect

class AbstractPyModbusDriver(AbstractModbusDriver):
    def __init__(self, config):
        self.client = self.create_client(config)
        self._detect_device_id_key()

    def create_client(self, config):
        raise Exception("create_client is abstract, you need to implement this method in a subclass of PyModbusDriver")

    def _detect_device_id_key(self):
        signature = inspect.signature(self.client.read_coils)
        device_id_keys = ["slave", "device_id"]
        count = 0
        for key in device_id_keys:
            if key in signature.parameters:
                self.device_id_key = key
                count += 1
                if count > 1:
                    raise Exception("Cannot detect the argument for device id/slave in the current modbus library")

    def device_id(self, device):
        return {self.device_id_key: device}

    async def init(self):
        await self.client.connect()

    async def quit(self):
        self.client.close()

    async def read_coil_multi(self, device, addr, count):
        if count == 0:
            return []
        result = await self.client.read_coils(addr, count=count, **self.device_id(device))
        if result.isError():
            raise Exception(f"modbus error: {result}")
        return result.bits

    async def write_coil(self, device, addr, value):
        await self.client.write_coil(addr, value, **self.device_id(device))

    async def write_coil_multi(self, device, addr, values):
        await self.client.write_coils(addr, values, **self.device_id(device))

    async def read_reg_multi(self, device, addr, count):
        if count == 0:
            return []
        result = await self.client.read_holding_registers(addr, count=count, **self.device_id(device))
        if result.isError():
            raise Exception(f"modbus error: {result}")
        return result.registers

    async def write_reg(self, device, addr, value):
        await self.client.write_register(addr, value, **self.device_id(device))

    async def write_reg_multi(self, device, addr, values):
        await self.client.write_registers(addr, values, **self.device_id(device))

    async def read_di_multi(self, device, addr, count):
        if count == 0:
            return []
        result = await self.client.read_discrete_inputs(addr, count=count, **self.device_id(device))
        if result.isError():
            raise Exception(f"modbus error: {result}")
        return result.bits

    async def read_ireg_multi(self, device, addr, count):
        if count == 0:
            return []
        result = await self.client.read_input_registers(addr, count=count, **self.device_id(device))
        if result.isError():
            raise Exception(f"modbus error: {result}")
        return result.registers
