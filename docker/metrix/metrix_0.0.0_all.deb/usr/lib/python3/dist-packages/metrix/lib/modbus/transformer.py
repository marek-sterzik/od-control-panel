from metrix.schema import validation, check
from schema import Optional

from .operations import operations
from .transformers import transformers


def ModbusTransformer(config):
    if isinstance(config, str):
        config = {"type": config}
    if not check({Optional(object): object}, config):
        raise Exception("invalid modbus value config")
    if not check({"type": str, Optional(object): object}, config):
        raise Exception("missing type in value config")
    if not hasattr(transformers, config["type"]):
        raise Exception(f"invalid value type: {config['type']}")
    TransformerClass = getattr(transformers, config["type"])
    value_type = config["type"]
    del config["type"]
    try:
        if not check(TransformerClass.validation, config):
            raise Exception(f"value type {value_type} has invalid configuration")
    finally:
        config["type"] = value_type
    return TransformerClass(config)

