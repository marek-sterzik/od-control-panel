from metrix import client, message_type, validate, validation, random_id
from schema import Optional, Or

payload_base_schema = {"operation": str, object: object}

payload_schema = {
    "publish": {
        "topic": validation.topic,
        Optional("ui_config"): {object: object},
        Optional("classes"): Or(None, [str]),
        Optional("id"): Or(None, str)
    },
    "unpublish": Or({
        "topic": validation.topic,
        Optional("ui_config"): {object: object},
        Optional("classes"): Or(None, [str]),
    }, {
        "id": str,
    })
}

def match_record(record, payload):
    if record["topic"] != payload["topic"]:
        return False
    if record["classes"] != payload["classes"]:
        return False
    if record["ui_config"] != payload["ui_config"]:
        return False
    return True

runtime = {}

def finalize_record(payload):
    del payload["operation"]
    if "ui_config" not in payload:
        payload["ui_config"] = {}
    if "classes" not in payload:
        payload["classes"] = None
    if "id" not in payload:
        payload["id"] = None

def validate_message(msg):
    if not msg.validate_payload(payload_base_schema, False):
        print("invalid message", msg.to_string())
        return False
    operation = msg.payload["operation"]
    if operation not in payload_schema:
        return False
    del msg.payload["operation"]
    valid = msg.validate_payload(payload_schema[operation], False)
    msg.payload["operation"] = operation
    return valid

def get_published_configuration():
    return runtime["published"]

def publish(payload):
    if "id" in payload:
        unpublish_by_id(payload["id"])
    finalize_record(payload)
    if payload["id"] is None:
        payload["id"] = random_id("v")
    index = len(runtime["published"])
    runtime["published"].append(payload)
    if payload["id"] is not None:
        runtime["published_by_id"][payload["id"]] = index

def unpublish_by_index(index):
    if index < len(runtime["published"]) and index >= 0:
        id = runtime["published"][index]["id"]
        if id is not None:
            del runtime["published_by_id"][id]
        del runtime["published"][index]

def unpublish_by_id(id):
    if id in runtime["published_by_id"]:
        index = runtime["published_by_id"][id]
        unpublish_by_index(index)

def find_by_match(payload):
    for index, record in enumerate(runtime["published"]):
        if match_record(record, payload):
            return index
    return None

def unpublish_by_match(payload):
    finalize_record(payload)
    index = find_by_match(payload)
    if index is not None:
        unpublish_by_index(index)

def modify(payload):
    if payload["operation"] == "publish":
        publish(payload)
    elif payload["operation"] == "unpublish":
        if "id" in payload:
            unpublish_by_id(payload["id"])
        else:
            unpublish_by_match(payload)

def broadcast():
    config = get_published_configuration()
    client.broadcast(runtime["topic"], config)

def metrix_init():
    runtime["topic"] = client.get_config("publisher_topic", "_publisher", validation.topic)
    runtime["published"] = []
    runtime["published_by_id"] = {}
    client.listen(message_type.QUERY, runtime["topic"])
    client.listen(message_type.MESSAGE, runtime["topic"])
    client.schedule_loop(timeout=6000)

def metrix_recv(msg):
    if msg.msg_type == message_type.MESSAGE:
        if validate_message(msg):
            modify(msg.payload)
    broadcast()

def metrix_loop():
    pass

