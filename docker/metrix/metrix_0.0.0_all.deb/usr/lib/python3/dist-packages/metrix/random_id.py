import base64, uuid

def random_id(namespace = ""):
    return "_" + namespace + base64.urlsafe_b64encode(uuid.uuid4().bytes).decode("ascii").rstrip('=').replace("-", "_")
