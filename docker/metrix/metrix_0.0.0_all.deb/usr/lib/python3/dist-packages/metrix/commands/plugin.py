from ..process_arguments import get_topic, arg_from_json
from ..message_type import message_type

from pprint import pprint

help="load plugin"
aliases=["p"]

def configure(parser):
    parser.add_argument("plugin", nargs="*", help="one or more plugins to load, each plugin is either specified by its name or in JSON format when using plugin arguments")

def invoke(args):
    plugins = list(map(arg_from_json, args.plugin))

    if len(plugins) == 0:
        raise Exception("Please specify at least one plugin")

    module="metrix.proc.send_message"
    process_args = [message_type.CORE, "plugins", {"plugins": plugins, "libs": args.lib}, None, {"wait_for_plugin": True}]

    from ..client import client

    return client.run(module=module, server_url=args.url, arguments=process_args, pid=None)
