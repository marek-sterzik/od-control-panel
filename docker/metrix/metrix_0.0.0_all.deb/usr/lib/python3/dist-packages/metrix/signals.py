from .attrdict import attrdict

signals = attrdict()
signals["QUIT"] = "quit"
signals["TERMINATE"] = "terminate"

