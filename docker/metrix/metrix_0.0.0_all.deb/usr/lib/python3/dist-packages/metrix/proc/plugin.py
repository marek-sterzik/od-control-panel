import asyncio, json
from metrix import client
from schema import Optional, Or
from ..schema import check, validation
from ..plugin_loader import load_plugin
from ..logger import logger

def do_load_plugin(plugin_def):
    try:
        if not check(validation.plugin, plugin_def):
            raise Exception("invalid plugin descriptor: " + json.dumps(plugin_def))
        if isinstance(plugin_def, str):
            plugin_def = {"plugin": plugin_def}
        else:
            plugin_def = {**plugin_def}
        if "args" not in plugin_def:
            plugin_def["args"] = {}
        try:
            return {"plugin": plugin_def["plugin"], "messages": load_plugin(plugin_def["plugin"], plugin_def["args"])}
        except Exception as e:
            raise Exception(f"cannot load plugin '{plugin_def['plugin']}': {e}")
    except Exception as e:
        logger(f"plugin loading error: {e}", lev = logger.ERR)
        return None


async def metrix_async_process():
    for plugin_def in client.arguments:
        plugin = do_load_plugin(plugin_def)
        if plugin is None:
            return 1
        logger(f"loading plugin: {plugin['plugin']}")
        for msg in plugin["messages"]:
            client.put_message(msg)
        await client.flush()

    return 0
