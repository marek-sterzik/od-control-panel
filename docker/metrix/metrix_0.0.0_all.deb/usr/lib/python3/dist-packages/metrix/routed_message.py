class RoutedMessage:
    def __init__(self, msg, websockets, pids = []):
        self.msg = msg
        self.websockets = websockets
        self.pids = pids
