def metrix_plugin(plugin):
    modbus_topic = plugin.arg("modbus_topic", "_modbus")
    plugin.trigger([{"topic": modbus_topic, "msg_types": "write"}], "metrix.proc.modbus", [{"control_topic": modbus_topic}])


