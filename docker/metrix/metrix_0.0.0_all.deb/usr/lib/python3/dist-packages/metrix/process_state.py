from .attrdict import attrdict

process_state = attrdict()
process_state["CREATED"] = "created"
process_state["CONFIGURING"] = "configuring"
process_state["RUNNING"] = "running"
process_state["QUITTING"] = "quitting"
process_state["DISCONNECTED"] = "disconnected"
process_state["TERMINATED"] = "terminated"
process_state["NOT_RUNNING"] = "not_running" # sent only when explicitely querying the status of a dead process

