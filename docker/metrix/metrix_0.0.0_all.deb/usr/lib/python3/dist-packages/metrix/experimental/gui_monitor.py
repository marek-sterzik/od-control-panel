"""Lightweight GUI monitor with history plots using NiceGUI.

Connects directly to the metrix server via websocket, subscribes to
the requested topics, and displays live values with time-series plots.

Usage:
    uv run python svc/gui-monitor vacuum.pressure vacuum.pump_enabled
    uv run python svc/gui-monitor --url ws://localhost:8765 vacuum.pressure

Opens a browser at http://localhost:8080 with:
    - A card per topic showing the current value and last update time.
    - A combined history plot with all numeric topics.
"""

import asyncio, json, time, argparse, sys
from datetime import datetime
from collections import deque

from nicegui import ui, app


# ---------------------------------------------------------------------------
# State
# ---------------------------------------------------------------------------
MAX_HISTORY = 300  # data points per topic (5 min at 1 Hz)

_topics: list[str] = []
_state: dict[str, dict] = {}          # topic -> {value, updated, history_t, history_v}
_ws_url: str = "ws://localhost:8765"
_connected: bool = False


def _init_topic(topic: str):
    _state[topic] = {
        "value": None,
        "updated": None,
        "history_t": deque(maxlen=MAX_HISTORY),
        "history_v": deque(maxlen=MAX_HISTORY),
        "is_bool": False,
    }


# ---------------------------------------------------------------------------
# WebSocket client (runs in background)
# ---------------------------------------------------------------------------
async def _ws_client():
    global _connected
    import websockets.asyncio.client as wsc

    while True:
        try:
            async with wsc.connect(_ws_url) as ws:
                _connected = True
                # Subscribe to all topics
                for topic in _topics:
                    msg = json.dumps(["core", "listen", {"msg_type": "broadcast", "topic": topic}])
                    await ws.send(msg)
                    # Also send initial query
                    msg = json.dumps(["query", topic])
                    await ws.send(msg)

                async for raw in ws:
                    try:
                        data = json.loads(raw)
                    except json.JSONDecodeError:
                        continue
                    if not isinstance(data, list) or len(data) < 2:
                        continue
                    msg_type, topic = data[0], data[1]
                    payload = data[2] if len(data) > 2 else None

                    if topic in _state:
                        now = time.perf_counter()
                        _state[topic]["value"] = payload
                        _state[topic]["updated"] = datetime.now()
                        # Record values for plotting
                        if isinstance(payload, bool):
                            _state[topic]["history_t"].append(now)
                            _state[topic]["history_v"].append(int(payload))
                            _state[topic]["is_bool"] = True
                        elif isinstance(payload, (int, float)):
                            _state[topic]["history_t"].append(now)
                            _state[topic]["history_v"].append(float(payload))

        except Exception:
            _connected = False
            await asyncio.sleep(2)  # reconnect after delay


# ---------------------------------------------------------------------------
# UI
# ---------------------------------------------------------------------------
def _build_ui():
    ui.dark_mode(True)

    with ui.header().classes("items-center justify-between"):
        ui.label("Metrix Monitor").classes("text-xl font-bold")
        with ui.row().classes("items-center gap-2"):
            paused = {"value": False}
            pause_btn = ui.button(icon="pause", on_click=lambda: None).props("flat dense round color=white")
            def toggle_pause():
                paused["value"] = not paused["value"]
                pause_btn._props["icon"] = "play_arrow" if paused["value"] else "pause"
                pause_btn.update()
            pause_btn.on_click(toggle_pause)
            status_label = ui.label("connecting...").classes("text-sm")

    # Value cards
    value_labels: dict[str, ui.label] = {}
    time_labels: dict[str, ui.label] = {}

    with ui.row().classes("w-full flex-wrap gap-4 p-4"):
        for topic in _topics:
            with ui.card().classes("min-w-[220px]"):
                ui.label(topic).classes("text-sm text-gray-400")
                value_labels[topic] = ui.label("...").classes("text-2xl font-mono")
                time_labels[topic] = ui.label("never").classes("text-xs text-gray-500")

    # Combined plot with subplots: numeric (top, 90%) + boolean (bottom, 10%)
    plot = ui.plotly({
        "data": [],
        "layout": {
            "height": 420,
            "template": "plotly_dark",
        },
    }).classes("w-full p-4")

    # Periodic UI update
    def update():
        # Status
        status_label.text = "connected" if _connected else "reconnecting..."
        status_label.classes(replace="text-sm " + ("text-green-400" if _connected else "text-red-400"))

        # Value cards always update (even when paused)
        for topic in _topics:
            s = _state.get(topic)
            if s is None:
                continue
            v = s["value"]
            value_labels[topic].text = f"{v}" if v is not None else "..."
            if s["updated"]:
                time_labels[topic].text = s["updated"].strftime("%H:%M:%S")

        # Skip plot update when paused so user can inspect data
        if paused["value"]:
            return

        # Split topics into numeric vs boolean
        now = time.perf_counter()
        numeric_traces = []
        bool_traces = []
        for topic in _topics:
            s = _state.get(topic)
            if s is None or len(s["history_t"]) == 0:
                continue
            x = [t - now for t in s["history_t"]]  # seconds ago
            y = list(s["history_v"])
            if s["is_bool"]:
                bool_traces.append((topic, x, y))
            else:
                numeric_traces.append((topic, x, y))

        has_bool = len(bool_traces) > 0
        has_numeric = len(numeric_traces) > 0
        if not has_bool and not has_numeric:
            return

        # Build layout with subplots using plain dicts (no plotly Python pkg)
        data = []
        layout = {
            "height": 420,
            "template": "plotly_dark",
            "margin": {"l": 50, "r": 20, "t": 30, "b": 40},
            "legend": {"orientation": "h", "y": -0.08},
        }

        if has_bool and has_numeric:
            # Two-row subplot: yaxis (90%) + yaxis2 (10%)
            layout["xaxis"] = {"anchor": "y", "showticklabels": False}
            layout["xaxis2"] = {"anchor": "y2", "title": "time (s ago)", "matches": "x"}
            layout["yaxis"] = {"domain": [0.12, 1.0], "title": "value"}
            layout["yaxis2"] = {
                "domain": [0.0, 0.10],
                "tickvals": [0, 1], "ticktext": ["off", "on"],
                "range": [-0.1, 1.1],
            }
            for topic, x, y in numeric_traces:
                data.append({"x": x, "y": y, "type": "scatter", "mode": "lines",
                             "name": topic, "xaxis": "x", "yaxis": "y"})
            for topic, x, y in bool_traces:
                data.append({"x": x, "y": y, "type": "scatter", "mode": "lines",
                             "name": topic, "line": {"shape": "hv"},
                             "xaxis": "x2", "yaxis": "y2"})
        else:
            layout["xaxis"] = {"title": "time (s ago)"}
            if has_bool:
                layout["yaxis"] = {"tickvals": [0, 1], "ticktext": ["off", "on"],
                                   "range": [-0.1, 1.1]}
            else:
                layout["yaxis"] = {"title": "value"}
            traces = numeric_traces if has_numeric else bool_traces
            for topic, x, y in traces:
                trace = {"x": x, "y": y, "type": "scatter", "mode": "lines", "name": topic}
                if has_bool:
                    trace["line"] = {"shape": "hv"}
                data.append(trace)

        plot.update_figure({"data": data, "layout": layout})

    ui.timer(1.0, update)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    global _topics, _ws_url

    parser = argparse.ArgumentParser(description="Metrix GUI Monitor")
    parser.add_argument("-u", "--url", default="ws://localhost:8765",
                        help="Metrix server URL (default: ws://localhost:8765)")
    parser.add_argument("-p", "--port", type=int, default=8080,
                        help="GUI web server port (default: 8080)")
    parser.add_argument("topics", nargs="+", help="Topics to monitor")
    args = parser.parse_args()

    _ws_url = args.url
    _topics = args.topics
    for topic in _topics:
        _init_topic(topic)

    _build_ui()

    app.on_startup(lambda: asyncio.create_task(_ws_client()))
    try:
        ui.run(title="Metrix Monitor", port=args.port, reload=False)
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
