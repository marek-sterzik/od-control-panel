import argparse, importlib, sys, os, re
import metrix.commands as commands
import urllib.parse

from pprint import pprint

def detect_argv0():
    argv0 = sys.argv[0]
    commandDir = os.path.dirname(argv0)
    commandName = os.path.basename(argv0)
    if commandDir[0:1] == '/':
        for path in os.getenv("PATH", "").split(":"):
            if path == '':
                continue
            if commandDir == path:
                return commandName
            testCommand = path + "/" + commandName
            if os.path.isfile(testCommand) and os.access(testCommand, os.X_OK) and not os.path.samefile(argv0, testCommand):
                return argv0
    return argv0


def load_commands():
    cmds = {}
    for mod in commands.__loader__.get_resource_reader().contents():
        if re.match(r'^[_\.]', mod):
            continue
        m = re.match(r'^([a-z0-9]+(-[a-z0-9]+)*)\.py$', mod)
        if not m:
            continue
        
        mod_name = m[1]

        command_name = re.sub(r'_', '-', mod_name)

        cmds[command_name] = importlib.import_module("metrix.commands." + mod_name)
    return cmds

def setup_global_options(parser, subcommand):
    dest_prefix = "" if subcommand else "_"
    urlgroup = parser.add_mutually_exclusive_group()
    urlgroup.add_argument('-u', '--url', default=None, dest=dest_prefix + "url", metavar="URL", help="metrix server url")
    urlgroup.add_argument('-t', '--port', default=None, dest=dest_prefix + "port", metavar="PORT", type=int, help="metrix server port")
    parser.add_argument("-l", "--lib", default=[], dest=dest_prefix + "lib", metavar="LIB", action="append", help="add python library path before invoking command")


global_arguments = ["url", "port", "lib"]

def finalize_global_arguments(args):
    for arg in global_arguments:
        global_value = getattr(args, "_" + arg)
        local_value = getattr(args, arg)
        if isinstance(global_value, list) and isinstance(local_value, list):
            final_value = global_value + local_value
        else:
            if local_value is None:
                final_value = global_value
            else:
                final_value = local_value
        setattr(args, arg, final_value)
        delattr(args, "_" + arg)

def create_subparser(subparsers, command_name, module, master_parser, help, aliases):
    parser = subparsers.add_parser(command_name, help=help, aliases=aliases)
    setup_global_options(parser, True)
    module.configure(parser)

def create_parser(cmds, aliases):
    parser = argparse.ArgumentParser(
        prog = detect_argv0(),
        description = "metrix server",
    )

    setup_global_options(parser, False)

    subparsers = parser.add_subparsers(title="commands", metavar="<command>", required=True, dest="_command")

    for command_name, command_module in cmds.items():
        help = ""
        if hasattr(command_module, "help"):
            help = command_module.help
        create_subparser(subparsers, command_name, command_module, parser, help, aliases[command_name])

    return parser

def is_local_url(url_parsed):
    if url_parsed.query != '':
        return False
    if url_parsed.path != '' and url_parsed.path != '/':
        return False
    if url_parsed.scheme != 'ws':
        return False
    if url_parsed.hostname not in ["localhost", "::1", "127.0.0.1"]:
        return False
    return True

def parse_url(url):
    try:
        url_parsed = urllib.parse.urlparse(url)
        if url_parsed.scheme not in ["ws", "wss"]:
            raise Exception("not a websocket url")
        if url_parsed.fragment != "":
            raise Exception("use url without fragment part")

    except Exception as e:
        print(f"Error: invalid url: {url} ({e})", file=sys.stderr)
        sys.exit(1)
    port = url_parsed.port
    if port is None:
        port = 8765
        netloc = f"{url_parsed.netloc}:{port}"
        url = urllib.parse.urlunparse((url_parsed.scheme, netloc, url_parsed.path, url_parsed.params, url_parsed.query, ''))

    if not is_local_url(url_parsed):
        port = None
    return url, port

def finalize_url_arguments(args):
    if "url" in args and args.url is not None:
        url = args.url
        url, port = parse_url(url)
    else:
        if "port" in args and args.port is not None:
            port = args.port
        else:
            port = 8765
            if "METRIX_PORT" in os.environ:
                try:
                    env_port = int(os.environ["METRIX_PORT"])
                    if env_port > 0 and env_port < 65535:
                        port = env_port
                except:
                    pass
        if port <= 0 or port >= 65536:
            print("Error: invalid port number", file=sys.stderr)
            sys.exit(1)
        url = f"ws://localhost:{port}"
    args.url = url
    args.port = port

def finalize_lib_arguments(args):
    libs = {}
    for lib in args.lib:
        if not os.path.isdir(lib):
            continue
        lib = os.path.realpath(lib)
        libs[lib] = True
    args.lib = list(libs.keys())

def finalize_arguments(args):
    finalize_global_arguments(args)
    finalize_url_arguments(args)
    finalize_lib_arguments(args)

def invoke_command(module, args):
    try:
        return module.invoke(args)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)

def create_aliases(cmds):
    aliases = {}
    reverse_aliases = {}
    for command_name, command_module in cmds.items():
        help = ""
        command_aliases = []
        if hasattr(command_module, "aliases"):
            command_aliases = command_module.aliases
        aliases[command_name] = command_aliases
        for alias in command_aliases:   
            reverse_aliases[alias] = command_name
    return aliases, reverse_aliases

def invoke():
    cmds = load_commands()
    aliases, reverse_aliases = create_aliases(cmds)
    parser = create_parser(cmds, aliases)
    args = parser.parse_args()

    finalize_arguments(args)

    cmd = args._command
    if cmd not in cmds and cmd in reverse_aliases:
        cmd = reverse_aliases[cmd]
    module = cmds[cmd]

    ret = invoke_command(module, args)

    if not isinstance(ret, int):
        if ret is True:
            ret = 0
        elif ret is False:
            ret = 1
        elif ret is None:
            ret = 0
        else:
            ret = 1
    sys.exit(ret)
