import sys

def patchlib(libs):
    for lib in libs:
        if lib not in sys.path:
            sys.path.append(lib)
