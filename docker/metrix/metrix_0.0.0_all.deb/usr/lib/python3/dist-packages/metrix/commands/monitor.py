from ..process_arguments import parse_process_arguments

from pprint import pprint

help="run metrix monitor"
aliases=["m"]

def configure(parser):
    parser.add_argument("-T", "--publisher-topic", default=None, help="set publisher topic")

def invoke(args):
    module = "metrix.proc.monitor"
    process_args = []
    config = {}
    if args.publisher_topic is not None:
        config["publisher_topic"] = args.publisher_topic
    process_args = [config]

    from ..client import client
    return client.run(module=module, server_url=args.url, arguments=process_args, pid=None)
