from metrix.attrdict import attrdict
from metrix.schema import check as schema_check, validation
from schema import And

def with_check(schema, value, msg, fn):
    if not schema_check(schema, value):
        raise Exception(msg)
    return fn

check = attrdict()
check["coil"] = bool
check["coil_multi"] = [check.coil]
check["reg"] = And(int, validation.range(0, 65535))
check["reg_multi"] = [check.reg]

operations = attrdict()
operations["read_coil"] = lambda: lambda driver, device, addr: driver.read_coil(device, addr)
operations["read_coil_multi"] = lambda count: lambda driver, device, addr: driver.read_coil_multi(device, addr, count)
operations["write_coil"] = lambda value: with_check(
    check.coil,
    value,
    "coil value must be a boolean",
    lambda driver, device, addr: driver.write_coil(device, addr, value)
)
operations["write_coil_multi"] = lambda values: with_check(
    check.coil_multi,
    values,
    "coil values must be an array of booleans",
    lambda driver, device, addr: driver.write_coil_multi(device, addr, values)
)


operations["read_reg"] = lambda: lambda driver, device, addr: driver.read_reg(device, addr)
operations["read_reg_multi"] = lambda count: lambda driver, device, addr: driver.read_reg_multi(device, addr, count)
operations["write_reg"] = lambda value: with_check(
    check.reg,
    value,
    "register value must be uint16",
    lambda driver, device, addr: driver.write_reg(device, addr, value)
)
operations["write_reg_multi"] = lambda values: with_check(
    check.reg_multi,
    values,
    "register values must be an array of uint16",
    lambda driver, device, addr: driver.write_reg_multi(device, addr, values)
)


operations["read_di"] = lambda: lambda driver, device, addr: driver.read_di(device, addr)
operations["read_di_multi"] = lambda count: lambda driver, device, addr: driver.read_di_multi(device, addr, count)
operations["write_di"] = lambda value: with_check(
    check.coil,
    value,
    "discrete input value must be a boolean",
    lambda driver, device, addr: driver.write_di(device, addr, value)
)
operations["write_di_multi"] = lambda values: with_check(
    check.coil_multi,
    values,
    "discrete input values must be an array of booleans",
    lambda driver, device, addr: driver.write_di_multi(device, addr, values)
)


operations["read_ireg"] = lambda: lambda driver, device, addr: driver.read_ireg(device, addr)
operations["read_ireg_multi"] = lambda count: lambda driver, device, addr: driver.read_ireg_multi(device, addr, count)
operations["write_ireg"] = lambda value: with_check(
    check.reg,
    value,
    "input register value must be uint16",
    lambda driver, device, addr: driver.write_ireg(device, addr, value)
)
operations["write_ireg_multi"] = lambda values: with_check(
    check.reg_multi,
    values,
    "input register values must be an array of uint16",
    lambda driver, device, addr: driver.write_ireg_multi(device, addr, values)
)
