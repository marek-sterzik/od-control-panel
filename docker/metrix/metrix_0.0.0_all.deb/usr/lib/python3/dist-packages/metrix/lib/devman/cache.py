from .list import list_all_devices
from time import time

cache_validity = 5

cache = {"timestamp": None, "devices": []}

def list_devices_cached(force_refetch = False):
    fetched = False
    if force_refetch or cache["timestamp"] is None or cache["timestamp"] + cache_validity < time():
        fetched = True
        cache["timestamp"] = time()
        cache["devices"] = list_all_devices()
    return {"fetched": fetched, "devices": cache["devices"]}
