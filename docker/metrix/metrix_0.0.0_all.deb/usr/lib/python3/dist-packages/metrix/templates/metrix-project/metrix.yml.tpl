name: '${_project_name}'
main: '${package}.proc.main'
