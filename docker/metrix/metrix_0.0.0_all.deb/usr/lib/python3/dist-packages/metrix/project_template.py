import os, re
from .project_template_instance import ProjectTemplateInstance
from .template_variable_types import var_types

_TEMPLATES_ROOT = os.path.join(os.path.dirname(__file__), "templates")

def list_template_names() -> list[str]:
    """Return available template directory names (sorted)."""
    if not os.path.isdir(_TEMPLATES_ROOT):
        return []
    return sorted(
        d for d in os.listdir(_TEMPLATES_ROOT)
        if d not in [".", ".."] and os.path.isdir(os.path.join(_TEMPLATES_ROOT, d)) and not d.startswith("_")
    )

def get_templates_meta_info():
    from .templates import TEMPLATES_META
    templates = {}
    default = None
    first = None
    for name in list_template_names():
        if first is None:
            first = name
        meta = TEMPLATES_META.get(name, {})
        if meta.get("default") and default is None:
            default = name
        description = meta.get("description", None)
        variables = meta.get("variables", [])
        templates[name] = {"description": description, "variables": variables, "default": False}
    if default is None:
        default = first
    if default is not None:
        templates[default]["default"] = True
    return {"templates": templates, "default": default}

class VariableMeta:
    def __init__(self, meta):
        self.meta = meta
    def name(self):
        return self.meta["name"]
    def help(self):
        return self.meta.get("help", None)
    def prompt(self):
        return self.meta["prompt"]
    def default_value(self, variables = {}):
        return self.meta["default"](variables) if callable(self.meta["default"]) else self.meta["default"]

    def process(self, str_value, variables):
        writes = {}
        value = self.meta["type"](str_value)
        if "postprocess" in self.meta:
            writes = self.meta["postprocess"](value, variables)
        writes[self.meta["name"]] = value

        for index, value in writes.items():
            variables[index] = value

class ProjectTemplate:
    def __init__(self, source_dir, meta):
        self.source_dir = source_dir
        self.meta = meta
        self.collection = None

    def _set_collection(self, collection):
        self.collection = collection

    def name(self):
        return self.meta["name"]

    def default(self):
        return self.collection is not None and self.collection.get_default() is self

    def description(self):
        return self.meta["description"]

    def variables(self):
        return map(lambda var_def: VariableMeta(var_def), self.meta["variables"])

    def instantiate(self, variables):
        return ProjectTemplateInstance(self, variables)


class ProjectTemplateCollection:
    def __init__(self, templates, default):
        self.templates = {}
        self.order = []
        for template in templates:
            template._set_collection(self)
            name = template.name()
            self.templates[name] = template
        for template in templates:
            if self.templates[template.name()] is template:
                self.order.append(template)

        if default is not None and default in self.templates:
            self.default = self.templates[default]
        else:
            self.default = None

    def __iter__(self):
        for template in self.order:
            yield template

    def get(self, name):
        if name is None:
            return self.get_default()
        if name not in self.templates:
            raise Exception(f"template does not exist: {name}")
        return self.templates[name]

    def get_default(self):
        if self.default is None:
            raise Exception(f"default template does not exist")
        return self.default


def create_tpl_collection():
    templates = []
    tpl_meta = get_templates_meta_info()
    for name, info in tpl_meta["templates"].items():
        info["name"] = name
        templates.append(ProjectTemplate(os.path.join(ProjectTemplateInstance.templates_root, name), info))
    return ProjectTemplateCollection(templates, tpl_meta["default"])

TPL_COLLECTION = None

def list_templates():
    global TPL_COLLECTION
    if TPL_COLLECTION is None:
        TPL_COLLECTION = create_tpl_collection()
    return TPL_COLLECTION



def slugify(name: str, default: str) -> str:
    s = name.strip().lower()
    s = re.sub(r"[^a-z0-9]+", "_", s)
    s = s.strip("_")
    return s or default

def project_name_postprocess(project_name, variables):
    slug = slugify(project_name, "my_project")
    output = variables.get("_output", None)
    if output is None:
       output = slug
    return {"_project_name_slug": slug, "_output": output}

def project_name_default(variables):
    output = variables.get("_output", None)
    if output is not None:
        output = os.path.basename(output)
    return output

project_name_meta = VariableMeta({
    "name": "_project_name",
    "help": "Project name",
    "prompt": "Project name",
    "default": project_name_default,
    "type": var_types.str,
    "postprocess": project_name_postprocess,
})
