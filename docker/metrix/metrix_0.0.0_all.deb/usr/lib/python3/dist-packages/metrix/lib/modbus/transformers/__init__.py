from metrix.attrdict import attrdict
from .coil import CoilTransformer
from .discrete_input import DiscreteInputTransformer
from .register import RegisterTransformer
from .input_register import InputRegisterTransformer
from .float import FloatTransformer
from .coils_num import CoilsNumTransformer

transformers = attrdict()
transformers["coil"] = CoilTransformer
transformers["discrete_input"] = DiscreteInputTransformer
transformers["register"] = RegisterTransformer
transformers["input_register"] = InputRegisterTransformer
transformers["float"] = FloatTransformer
transformers["coils_num"] = CoilsNumTransformer
