from .schema import validation, validate
from schema import Optional, Or
import os, yaml

DEFAULT_MANIFEST_FILE = "metrix.yml"

def real_lib_path(lib, manifest_dir):
    if os.path.isabs(lib):
        lib_rel = lib
    else:
        lib_rel = os.path.join(manifest_dir, lib)
    if not os.path.isdir(lib_rel):
        raise Exception(f"manifest file contains invalid directory: {lib}")
    return os.path.realpath(lib_rel)

manifest_schema = {
    Optional("name"): Or(None, str),
    Optional("current_dir_is_lib"): bool,
    Optional("libs"): Or(None, [str]),
    Optional("main"): Or(None, validation.module),
    Optional("arguments"): Or(None, [object]),
    Optional("plugins"): validation.plugins
}

def create_project_libs(libs, project_dir_is_lib, project_dir):
    if libs is None:
        libs = []
    if project_dir_is_lib and project_dir is not None:
        libs.append(".")
    return list(real_lib_path(lib, project_dir) for lib in libs)

def create_project_main_process(module, arguments):
    if module is None and arguments is not None:
        raise Exception("invalid manifest file: don't arguments without specifying the main process module")
    if arguments is None:
        arguments = []

    return [module] + arguments if module is not None else None

class MetrixManifest:
    def __init__(self, data, project_dir):
        self._name = data.get("name", None)
        self._project_dir = project_dir
        self._libs = create_project_libs(data.get("libs", None), data.get("current_dir_is_lib", True), project_dir)
        self._main = create_project_main_process(data.get("main", None), data.get("arguments", None))
        self._plugins = data.get("plugins", [])

    def name(self):
        return self._name

    def libs(self):
        return self._libs

    def main(self):
        return self._main

    def project_dir(self):
        return self._project_dir

    def plugins(self):
        return self._plugins

def load_manifest(path):
    if path is not None:
        if os.path.isdir(path):
            project_dir = path
            manifest_file = os.path.join(path, DEFAULT_MANIFEST_FILE)
        else:
            manifest_file = path
            project_dir = os.path.dirname(path)
            if project_dir == "":
                project_dir = "."
        if not os.path.isdir(project_dir):
            raise Exception("project must point to an existing directory or a manifest file")
        if not os.path.isfile(manifest_file):
            raise Exception(f"project directory must contain a manifest file '{DEFAULT_MANIFEST_FILE}'")
        project_dir = os.path.realpath(project_dir)
        with open(manifest_file) as stream:
            manifest_data = yaml.safe_load(stream)
    else:
        project_dir = None
        manifest_data = {}
    manifest_data = validate(manifest_schema, manifest_data)
    return MetrixManifest(manifest_data, project_dir)
 
