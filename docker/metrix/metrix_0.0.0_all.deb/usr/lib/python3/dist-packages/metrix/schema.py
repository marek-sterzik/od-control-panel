from schema import Schema, And, Or, Use, Const, Optional, Forbidden, Hook, Regex, Literal, SchemaError
from .attrdict import attrdict
from .message_type import message_type
from .signals import signals

message_types = {v: True for k, v in message_type.items()}
signal_list = {v: True for k, v in signals.items()}

def check(schema, data):
    try:
        validate(schema, data)
        return True
    except:
        return False

def validate(schema, data):
    return Schema(schema).validate(data)

def enum(*values):
    return And(str, lambda t: t in values)

def _validate_polymorphic(key, subschemes, data, ignored_keys):
    variant = data[key]
    ignored_data = {}
    del data[key]
    for k in ignored_keys:
        if k in data:
            ignored_data[k] = data[k]
            del data[k]
    try:
        return check(subschemes[variant], data)
    finally:
        data[key] = variant
        for k in ignored_keys:
            if k in ignored_data:
                data[k] = ignored_data[k]

def polymorphic(key, subschemes, ignored_keys = []):
    variants = list(subschemes.keys())
    validate(str, key)
    global_scheme = {key: enum(*variants), Optional(object): object}
    return And(global_scheme, lambda t: _validate_polymorphic(key, subschemes, t, ignored_keys))

validation = attrdict()
validation['reference'] = Or(None, str)
validation['topic'] = And(str, Regex(r'^[a-zA-Z0-9_]+(\.[a-zA-Z0-9_]+)*$'))
validation['topic_pattern'] = And(str, Regex(r'^[a-zA-Z0-9_\*#]+(\.[a-zA-Z0-9_\*#]+)*$'))
validation['identifier'] = And(str, Regex(r'^[a-zA-Z0-9_]+(\.[a-zA-Z0-9_]+)*$'))
validation['msg_type'] = enum(*message_types)
validation['pid'] = And(str, Regex(r'^[a-zA-Z0-9_]+$'))
validation['module'] = And(str, Regex(r'^[a-z0-9_]+(\.[a-z0-9_]+)*$'))
validation['package'] = And(str, Regex(r'^[a-z0-9_]+$'))
validation['signal'] = enum(*signal_list)
validation['object'] = {Optional(object): object}
validation['enum'] = enum
validation['polymorphic'] = polymorphic
validation['range'] = lambda ge=None, le=None: lambda x: ((ge is None) or (ge <= x)) and ((le is None) or (le >= x))
validation['plugin'] = Or(validation.module, {"plugin": validation.module, Optional("args"): validation.object})
validation['plugins'] = [validation.plugin]
