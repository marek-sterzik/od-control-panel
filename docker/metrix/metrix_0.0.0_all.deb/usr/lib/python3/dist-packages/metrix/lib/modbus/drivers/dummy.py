from .abstract import AbstractModbusDriver

class ModbusDummyDriver(AbstractModbusDriver):
    """In-memory modbus driver. Used for testing/simulation without hardware.

    Supports all value types for writes (including discrete_input and
    input_register) so that mock simulators can pre-populate values.
    """
    def __init__(self, config):
        self.registers = {}
        self.coils = {}

    async def init(self):
        pass

    async def quit(self):
        pass

    async def read_coil_multi(self, device, addr, count):
        if (addr + count > 65536) or (count < 0):
            raise Exception("coil address interval out of range")
        ret = []
        for i in range(count):
            ra = addr + i
            ret.append(self.coils[ra] if ra in self.coils else False)
        return ret

    async def write_coil_multi(self, device, addr, values):
        count = len(values)
        if addr + count > 65536:
            raise Exception("coil address interval out of range")
        for i, value in enumerate(values):
            ra = addr + i
            self.coils[ra] = value

    async def read_reg_multi(self, device, addr, count):
        if (addr + count > 65536) or (count < 0):
            raise Exception("register address interval out of range")
        ret = []
        for i in range(count):
            ra = addr + i
            ret.append(self.registers[ra] if ra in self.registers else 0)
        return ret

    async def write_reg_multi(self, device, addr, values):
        count = len(values)
        if addr + count > 65536:
            raise Exception("register address interval out of range")
        for i, value in enumerate(values):
            ra = addr + i
            self.registers[ra] = value

    async def read_di_multi(self, device, addr, count):
        return await self.read_coil_multi(device, addr, count)
    
    async def read_ireg_multi(self, device, addr, count):
        return await self.read_reg_multi(device, addr, count)

    validation = {}

