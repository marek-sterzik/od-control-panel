from .attrdict import attrdict

class LifecycleState:
    def __init__(self, code):
        self.code = code

    def running(self):
        return self.code == 'running'

    def connection_available(self):
        return self.code in ("configuring", "running", "quitting")

    def needs_disconnected(self):
        return self.code in ("connecting", "configuring", "running")


lifecycle = attrdict()
lifecycle["CONNECTING"] = LifecycleState("connecting")
lifecycle["CONFIGURING"] = LifecycleState("configuring")
lifecycle["RUNNING"] = LifecycleState("running")
lifecycle["QUITTING"] = LifecycleState("quitting")
lifecycle["TERMINATING"] = LifecycleState("terminating")
lifecycle["TERMINATED"] = LifecycleState("terminated")

