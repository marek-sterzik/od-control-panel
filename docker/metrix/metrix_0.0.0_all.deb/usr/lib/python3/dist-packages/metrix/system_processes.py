from .schema import validation

system_processes = {
    "metrix.proc.publisher": {"publisher_topic": validation.topic}
}
