import time, asyncio
from metrix import client, message_type, validate, validation, logger
from metrix.lib.scheduler import Scheduler
from metrix.lib.modbus import ModbusDriver, ModbusTransformer
from schema import And, Or, Optional

COMMANDS_VALIDATION = {
    "add": {
        "busid": validation.identifier,
        "topic": validation.topic,
        "device": And(int, validation.range(ge=0, le=255)),
        "type": Or(str, {Optional(object): object}),
        "addr": And(int, validation.range(0, 65535)),
        Optional("read_interval"): Or(None, float, int),
        Optional("write_mode"): Or(None, validation.enum("w", "wr", "wb")),
    },
    "busadd": And({
        "busid": validation.identifier,
        Optional(object): object,
    }, ModbusDriver.validation(ignored_keys = ["busid"])),
    "remove": {
        "topic": validation.identifier,
    },
    "busremove": {
        "busid": validation.topic
    }
}

MESSAGE_VALIDATION = validation.polymorphic("command", COMMANDS_VALIDATION)

runtime = {}

class Modbus:
    def __init__(self, config):
        self.task = asyncio.create_task(self.run())
        self.queue = asyncio.Queue()
        self.driver = ModbusDriver(config)

    def post_command(self, command):
        self.queue.put_nowait(command)

    def shutdown(self):
        self.queue.put_nowait(None)  # sentinel to stop the consumer (compatible with Python <3.13)

    async def run(self):
        try:
            await self.driver.init()
            while True:
                command = await self.queue.get()
                if command is None:  # shutdown sentinel
                    break
                method = "do_" + command['operation']
                if hasattr(self, method):
                    await getattr(self, method)(command)
                else:
                    logger(f"unsupported modbus method: {method}", lev=logger.WARN)
        except asyncio.CancelledError:
            pass
        await self.driver.quit()

    async def do_read(self, command):
        try:
            ret = await self.driver.read(command["type"], command["device"], command["addr"])
            client.broadcast(command["topic"], ret)
        except Exception as e:
            client.error(command["topic"], {"message": f"cannot read modbus: {e}"})

    async def do_write(self, command):
        try:
            await self.driver.write(command["type"], command["device"], command["addr"], command["value"])
            if command['write_mode'] == "wb":
                client.broadcast(command["topic"], command["value"])
            elif command['write_mode'] == "wr":
                ret = await self.driver.read(command["type"], command["device"], command["addr"])
                client.broadcast(command["topic"], ret)
            elif command['write_mode'] == 'w':
                pass
            else:
                raise Exception(f"write mode '{command['write_mode']}' not implemented")
        except Exception as e:
            client.error(command["topic"], {"message": f"cannot write modbus: {e}"})
                
def process_busadd(command):
    busid = command["busid"]
    if busid in runtime["bus"]:
        raise Exception(f"cannot add bus '{busid}', bus already exist")

    bus = Modbus(command)
    runtime["bus"][busid] = {
        "bus": bus,
        "values": {},
    }
    return True

def do_command(busid, command):
    if busid in runtime["bus"]:
        bus = runtime["bus"][busid]["bus"]
        bus.post_command(command)


def do_write(topic, value):
    if topic not in runtime["values"]:
        raise Exception(f"cannot write topic {topic}, topic not registered")
    
    value_type = runtime["values"][topic]["type"]
    
    command = {
        "operation": "write",
        "device": runtime["values"][topic]["device"],
        "addr": runtime["values"][topic]["addr"],
        "type": value_type,
        "value": value,
        "write_mode": runtime["values"][topic]["write_mode"],
        "topic": topic,
    }

    do_command(runtime["values"][topic]["busid"], command)

def do_read(topic):
    if topic not in runtime["values"]:
        raise Exception(f"cannot read topic {topic}, topic not registered")
    command = {
        "operation": "read",
        "device": runtime["values"][topic]["device"],
        "addr": runtime["values"][topic]["addr"],
        "type": runtime["values"][topic]["type"],
        "topic": topic,
    }

    do_command(runtime["values"][topic]["busid"], command)

def setup_listeners(topic):
    client.listen(message_type.QUERY, topic)
    client.listen(message_type.WRITE, topic)

def remove_listeners(topic):
    client.unlisten(message_type.QUERY, topic)
    client.unlisten(message_type.WRITE, topic)

def remove_topic(topic):
    if topic in runtime["values"]:
        remove_listeners(topic)
        runtime["values"][topic]["read_interval"].remove()
        del runtime["values"][topic]
        del runtime["bus"]["values"][topic]


def process_busremove(command):
    busid = command["busid"]
    if busid not in runtime["bus"]:
        raise Exception(f"cannot remove bus '{busid}', bus does not exist")
    for topic in list(runtime["bus"][busid]["values"].keys()):
        remove_topic(topic)
    runtime["bus"][busid]["bus"].shutdown()
    del runtime["bus"][busid]
    return True

def process_add(command):
    if "write_mode" not in command or command["write_mode"] is None:
        command["write_mode"] = "w"

    busid = command["busid"]
    topic = command["topic"]
    device = command["device"]
    addr = command["addr"]
    read_interval = command["read_interval"]
    value_type = ModbusTransformer(command["type"])
    write_mode = command["write_mode"]

    if busid not in runtime["bus"]:
        raise Exception(f"cannot add topic {command['topic']}: missing bus '{busid}'")

    if topic in runtime["values"]:
        raise Exception(f"cannot add topic {command['topic']}: already added")
    
    if read_interval is not None:
        read_interval = runtime["scheduler"].schedule(
            interval=read_interval,
            at=time.time(),
            repeat=True,
            callback=lambda: do_read(topic)
        )

    runtime["values"][topic] = {
        "busid": busid,
        "device": device,
        "type": value_type,
        "addr": addr,
        "read_interval": read_interval,
        "write_mode": write_mode,
    }
    runtime["bus"][busid]["values"][topic] = True
    setup_listeners(topic)
    return True

def process_remove(command):
    topic = command["topic"]
    if topic not in runtime["values"]:
        raise Exception(f"cannot remove topic {topic}, topic does not exist")
    remove_topic(topic)
    return True

COMMANDS = {
    "add": process_add,
    "busadd": process_busadd,
    "remove": process_remove,
    "busremove": process_busremove
}

def process_command(command):
    cmd = command["command"]
    if cmd not in COMMANDS:
        return False
    try:
        return COMMANDS[cmd](command)
    except KeyboardInterrupt:
        raise
    except Exception as e:
        logger(f"cannot invoke {cmd}: {e}", lev = logger.WARN)
        # command was accepted even if it failed
        # the error message was already displayed and therefore
        # we return True suppressing the default error message
        return True


def metrix_init():
    runtime["topic"] = client.get_config("control_topic", "_modbus", validation.topic)
    runtime["scheduler"] = Scheduler()
    runtime["bus"] = {}
    runtime["values"] = {}
    client.listen(message_type.MESSAGE, runtime["topic"])

def metrix_loop():
    timeout = runtime["scheduler"].loop(6000)
    client.schedule_loop(timeout=timeout, wake_on_msg=True, oneshot=True)

def metrix_recv(msg):
    if msg.has_type(message_type.MESSAGE) and msg.has_topic(runtime["topic"]):
        if not msg.check_payload(MESSAGE_VALIDATION) or not process_command(msg.payload):
            logger(f"got invalid command: {msg.payload_as_string()}", lev=logger.WARN)
    try:
        if msg.has_type(message_type.QUERY):
            do_read(msg.topic)
        if msg.has_type(message_type.WRITE):
            do_write(msg.topic, msg.payload)
    except Exception as e:
        logger(f"{e}", lev = logger.WARN)

