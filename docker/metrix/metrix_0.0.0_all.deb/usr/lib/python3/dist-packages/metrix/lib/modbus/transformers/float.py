import struct
from .abstract_chain import AbstractChainTransformer
from metrix.schema import validation, check
from schema import Optional, Or
from .register import RegisterTransformer
from .input_register import InputRegisterTransformer
from ..utils import default

class FloatTransformer(AbstractChainTransformer):
    def __init__(self, config):
        ChainTransformer = RegisterTransformer if config["direction"] == "output" else InputRegisterTransformer
        self.swap_words = default(config, "swap_words", False)
        self.swap_whole = default(config, "swap_whole", False)
        self.double = default(config, "double", False)
        self.chain = ChainTransformer({"count": 4 if self.double else 2})

    def tr_read(self, value):
        value = self.swap(value)
        return self.double_from_uint16(value)

    def tr_write(self, value):
        value = self.uint16_from_double(value)
        return self.swap(value)

    def swap(self, value):
        if self.swap_words:
            value = list(map(lambda word: self.swap_word(word), value))
        if self.swap_whole:
            value.reverse()
        return value

    def swap_word(self, word):
        low = word & 0xff
        high = (word >> 8) & 0xff
        return (low << 8) | high

    def double_from_uint16(self, value):
        if self.double:
            a, = struct.unpack(">d", struct.pack(">HHHH", value[0], value[1], value[2], value[3]))
        else:
            a, = struct.unpack(">f", struct.pack(">HH", value[0], value[1]))
        return a

    def uint16_from_double(self, value):
        if self.double:
            a, b, c, d = struct.unpack(">HHHH", struct.pack(">d", value))
            return [a, b, c, d]
        else:
            a, b = struct.unpack(">HH", struct.pack(">f", value))
            return [a, b]

    validation = {
        "direction": validation.enum("input", "output"),
        Optional("swap_words"): Or(None, bool),
        Optional("swap_whole"): Or(None, bool),
        Optional("double"): Or(None, bool),
    }
