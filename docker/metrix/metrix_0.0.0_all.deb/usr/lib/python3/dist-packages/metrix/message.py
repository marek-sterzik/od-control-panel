import json
from .schema import validation, validate
from schema import SchemaError
from .attrdict import attrdict
from .message_type import message_type
from .topic_match import topic_match

def parse_category(category):
    parsed = category.split("@", 2)
    topic = parsed[0]
    if len(parsed) == 1:
        msg_type = None
    else:
        msg_type = parsed[1].lower()
    if topic == '':
        topic = None
    if msg_type == '':
        msg_type = None
    return msg_type, topic

def normalize_reference(reference):
    reference = validate(validation.reference, reference)
    if reference is None:
        reference = ""
    return reference

class message:
    type = message_type

    def __init__(self, msg_type, topic, payload = None, reference = None):
        self.msg_type = validate(validation.msg_type, msg_type)
        self.topic = validate(validation.topic, topic)
        self.payload = payload
        self.reference = normalize_reference(reference)


    def match(self, category):
        msg_type, topic = parse_category(category)
        if msg_type is not None and msg_type != self.msg_type:
            return False
        if topic is not None and not topic_match(self.topic, topic):
            return False
        return True

    def has_topic(self, topic):
        return topic_match(self.topic, topic)

    def has_type(self, msg_type):
        return self.msg_type == msg_type

    def to_string(self):
        data = [self.msg_type, self.topic]
        if self.payload is not None or self.reference != "":
            data.append(self.payload)
        if self.reference != "":
            data.append(self.reference)
        return json.dumps(data)

    def payload_as_string(self):
        return json.dumps(self.payload)

    def check_payload(self, schema):
        return self.validate_payload(schema, exception = False)

    def validate_payload(self, schema, exception = True):
        try:
            self.payload = validate(schema, self.payload)
            return True
        except SchemaError as e:
            if exception:
                raise e
            else:
                return False

    @staticmethod
    def from_string(msg):
        try:
            msg = json.loads(msg)
            if not isinstance(msg, list):
                return None
            if len(msg) < 2 or len(msg) > 4:
                return None
            return message(*msg)
        except:
            return None
