from .module_processor import module_processor
from websockets.asyncio.client import connect
from websockets.exceptions import ConnectionClosed
import asyncio, time, sys, importlib, signal
from .message import message, message_type
from .lifecycle import lifecycle
from .publisher import Publisher
from .expect_message import ExpectMessage
from .logger import logger, identify_logs
from .schema import check, validation
from .process_state import process_state

class ClientQuitException(Exception):
    def __init__(self, ret = 0):
        self.ret = ret


class MetrixClient:
    def __init__(self):
        self.arguments = []
        self.config = None
        self.pid = None

        self._message_consumers = {}
        self._functions = {}
        self._server_url = None
        self._queue = asyncio.Queue()
        self._quit_event = asyncio.Event()
        self._next_in = None
        self._next_at = None
        self._loop_timers = {"oneshot": None, "permanent": None}
        self._wait = {}
        self._state = lifecycle.CONNECTING

        self.publisher = Publisher(self)

    def get_config(self, key, default_value = None, validator = object):
        if self.config is not None and key in self.config:
            if check(validator, self.config[key]):
                return self.config[key]
            else:
                self._warning(f"invalid config value '{key}', ignoring")
                return default_value
        return default_value

    def get_arg_config(self, key, default_value = None, validator = object):
        if len(self.arguments) > 0 and check(validation.object, self.arguments[0]) and key in self.arguments[0]:
            if check(validator, self.arguments[0][key]):
                return self.arguments[0][key]
            else:
                self._warning(f"invalid argument config value '{key}', ignoring")
                return default_value
        return default_value

    def get_arg(self, index, default_value = None, validator = object):
        if len(self.arguments) > index and check(validator, self.arguments[index]):
            return self.arguments[index]
        else:
            return default_value

    def schedule_loop(self, timeout = None, until = None, wake_on_msg = False, oneshot = None):
        if (timeout is not None) and (until is not None):
            raise ValueError("set either 'timeout' or 'until' argument in schedule_loop, but not both")
        if timeout is not None:
            if oneshot is None:
                oneshot = False
            timeout_fun = lambda: timeout
        elif until is not None:
            if oneshot is None:
                oneshot = True
            if not oneshot:
                raise ValueError("cannot schedule 'until' wait not being oneshot in schedule_loop")
            timeout_fun = lambda: until - time.time()
        else:
            if oneshot is None:
                oneshot = False
            timeout_fun = lambda: 0

        timer = {"timeout": timeout_fun, "wake_on_msg": wake_on_msg}
        timer_slot = "oneshot" if oneshot else "permanent"
        self._loop_timers[timer_slot] = timer
        return self

    async def loop_wait(self):
        if self._loop_timers["oneshot"] is not None:
            timer = self._loop_timers["oneshot"]
            self._loop_timers["oneshot"] = None
        else:
            timer = self._loop_timers["permanent"]

        if timer is not None:
            timeout = timer["timeout"]()
            if timeout > 0:
                if timer["wake_on_msg"]:
                    await self.sleep_until_message(timeout)
                else:
                    await asyncio.sleep(timeout)
        return self

    def put_message(self, msg):
        if not self._state.connection_available():
            raise RuntimeError(f"Cannot send in state '{self._state}'")
        self._queue.put_nowait(msg)
        return self

    def send(self, msg_type, topic, payload = None, reference = None):
        self.put_message(message(msg_type, topic, payload, reference))
        return self

    async def flush(self):
        if not self._state.connection_available():
            return
        await self._queue.join()
    
    async def sleep_until_message(self, timeout):
        wait = asyncio.ensure_future(asyncio.sleep(timeout))
        self._wait[wait] = True
        try:
            await wait
        except asyncio.CancelledError as e:
            if not self._state.connection_available():
                raise e
        finally:
            if wait in client._wait:
                del client._wait[wait]

    def register_message_consumer(self, consumer):
        if consumer not in self._message_consumers:
            self._message_consumers[consumer] = 0
        self._message_consumers[consumer] += 1

    def unregister_message_consumer(self, consumer):
        if consumer in self._message_consumers:
            self._message_consumers[consumer] -= 1
            if self._message_consumers[consumer] <= 0:
                del self._message_consumers[consumer]

    def listen(self, msg_type, topic):
        self.send(message_type.CORE, "listen", {"msg_type": msg_type, "topic": topic})
        return self

    def unlisten(self, msg_type, topic):
        self.send(message_type.CORE, "unlisten", {"msg_type": msg_type, "topic": topic})
        return self

    def start(self, module_name, args = [], pid = None, libs = []):
        self.send(message_type.CORE, "start", {"module": module_name, "args": args, "pid": pid, "libs": libs})
        return self

    def trigger(self, topics, module_name, args=[], id = None, libs = []):
        self.send(message_type.CORE, "trigger", {"topics": topics, "module": module_name, "args": args, "id": id, "libs": libs})
        return self

    def plugins(self, plugins, libs = [], reference = None):
        self.send(message_type.CORE, "plugins", {"plugins": plugins, "libs": libs}, reference)
        return self

    def broadcast(self, topic, payload, reference = None):
        self.send(message_type.BROADCAST, topic, payload, reference = reference)
        return self

    def query(self, topic, payload = None, reference = None):
        self.send(message_type.QUERY, topic, payload, reference = reference)
        return self

    def message(self, topic, payload, reference = None):
        self.send(message_type.MESSAGE, topic, payload, reference = reference)
        return self

    def write(self, topic, payload, reference = None):
        self.send(message_type.WRITE, topic, payload, reference = reference)
        return self

    def error(self, topic, payload, reference = None):
        self.send(message_type.ERROR, topic, payload, reference = reference)
        return self

    def quit(self):
        if not self._state.running():
            return
        self.send(message_type.CORE, "quit")
        self._state = lifecycle.QUITTING
        self._quit_event.set()

    def terminate(self, ret = 0):
        self._state = lifecycle.TERMINATING
        raise ClientQuitException(ret)

    def signal(self, pid, signal):
        self.send(message_type.CORE, "signal", {"pid": pid, "signal": signal})
        return self

    def run(self, module, server_url, arguments = [], pid = None):
        if pid is not None:
            signal.signal(signal.SIGINT, lambda sig, frame: None)
        module = importlib.import_module(module)
        identify_logs(module.__name__)
        self._functions = module_processor(module, self)
        self._server_url = server_url

        self.config = None
        self.arguments = arguments
        self.pid = pid

        ret = 1
        try:
            asyncio.run(self._main())
        except ClientQuitException as e:
            ret = e.ret
        except ConnectionClosed:
            ret = 1
        except KeyboardInterrupt:
            print("", file=sys.stderr)
            ret = 1
        if self._functions['cleanup'] is not None:
            self._functions['cleanup']()
        return ret

    async def wait_process(self, pid):
        expect = self.expect_message(
            lambda msg: msg.has_type(message_type.PROCESS) and msg.has_topic(pid) and \
                (msg.payload not in [process_state.CREATED, process_state.CONFIGURING]),
            False
        )
        expect.start()
        self.listen(message_type.PROCESS, pid)
        self.send(message_type.PROCESS, pid)
        msg = await expect.wait()
        self.unlisten(message_type.PROCESS, pid)
        return msg.payload == process_state.RUNNING

    def _warning(self, msg):
        if self.pid is None:
            print(f"Warning: {msg}", file = sys.stderr)
        else:
            logger(msg, lev = logger.WARN)

    async def _recv_finished(self):
        await self.flush()
        for wait in list(self._wait.keys()):
            wait.cancel()
            del self._wait[wait]

    def _get_sleep_time(self):
        if self._next_at is not None:
            timeout = self._next_at - time.time()
        elif self._next_in is not None:
            timeout = self._next_in
        else:
            timeout = 0
        if timeout < 0:
            timeout = 0
        return timeout

    async def _main(self):
        self._state = lifecycle.CONNECTING
        try:
            async with connect(self._server_url) as websocket:
                self._state = lifecycle.CONFIGURING
                await asyncio.gather(
                    self._run_process(websocket),
                    self._writer(websocket),
                    self._reader(websocket)
                )
        finally:
            self._state = lifecycle.TERMINATED

    def expect_message(self, checker, block_nonmatching_messages = False):
        return ExpectMessage(self, checker, block_nonmatching_messages)

    async def _configure_handshake(self, configuring):
        expect = self.expect_message(
            lambda msg: msg.msg_type == message_type.CORE and msg.topic == "register",
            True
        )
        expect.start()
        self.send(message_type.CORE, "register", {"pid": self.pid, "configuring": configuring})
        msg = await expect.wait()
        if "config" in msg.payload and check(validation.object, msg.payload['config']):
            self.config = msg.payload['config']
        else:
            self.config = {}
        self._state = lifecycle.CONFIGURING if configuring else lifecycle.RUNNING

    async def _run_process(self, websocket):
        ret = await self._functions["main_process"]()
        if not isinstance(ret, int):
            ret = 0 if ret is None else 1
        await self.flush()
        self.terminate(ret)

    def _handle_core_message(self, msg):
        if msg.topic == "quit":
            self.quit()
        elif msg.topic == "terminate":
            # terminate message does not need any
            # handler. It is used just for the purpose,
            # server connection thread will not get
            # stucked
            pass 

    async def _reader(self, websocket):
        async for raw in websocket:
            msg = message.from_string(raw)
            if msg is None:
                continue
            consumed = False
            for consumer in self._message_consumers.keys():
                if consumer(msg):
                    consumed = True
            if (msg.msg_type == message_type.CORE):
                self._handle_core_message(msg)
                recv = "core_recv"
            else:
                recv = "recv"

            if not consumed and self._functions[recv] is not None:
                await self._functions[recv](msg)
                await self._recv_finished()
        self.terminate(1)

    async def _writer(self, websocket):
        while True:
            msg = await self._queue.get()
            try:
                await websocket.send(msg.to_string())
            finally:
                self._queue.task_done()

client = MetrixClient()
