from metrix.attrdict import attrdict

from .find import find_device
from .query import query_device, query_devices

device_class = attrdict()

devman = attrdict()
devman['find'] = find_device
devman['qdev'] = query_device
devman['qdevs'] = query_devices
devman['SERIAL'] = "serial"
devman['ALL'] = "all"
