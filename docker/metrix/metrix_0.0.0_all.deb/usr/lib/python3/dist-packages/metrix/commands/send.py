from ..process_arguments import get_topic, arg_from_json
from ..message_type import message_type

from pprint import pprint

help="send message"
aliases=["d"]

def configure(parser):
    group = parser.add_mutually_exclusive_group()
    group.add_argument("-c", "--core", action="store_true", help="send a core message")
    group.add_argument("-b", "--broadcast", action="store_true", help="broadcast a value")
    group.add_argument("-q", "--query", action="store_true", help="query a value")
    group.add_argument("-m", "--message", action="store_true", help="send a message")
    group.add_argument("-p", "--process", action="store_true", help="send a process query")
    group.add_argument("-e", "--error", action="store_true", help="send an error message")
    group.add_argument("-w", "--write", action="store_true", help="send a write message")
    parser.add_argument("topic", nargs=1, help="topic of the message")
    parser.add_argument("payload", nargs="?", help="payload of the message (JSON encoded)")

def get_message_type(args):
    if args.core:
        return message_type.CORE
    elif args.broadcast:
        return message_type.BROADCAST
    elif args.query:
        return message_type.QUERY
    elif args.message:
        return message_type.MESSAGE
    elif args.process:
        return message_type.PROCESS
    elif args.error:
        return message_type.ERROR
    elif args.write:
        return message_type.WRITE
    raise Exception("message must be specified using options --core, --broadcast, --query, --message, --process, --write or --error")

def invoke(args):
    message_type = get_message_type(args)
    topic = get_topic(args.topic[0])
    payload = args.payload
    if payload is not None:
        payload = arg_from_json(payload)

    module = "metrix.proc.send_message"
    process_args = [message_type, topic, payload]

    from ..client import client

    return client.run(module=module, server_url=args.url, arguments=process_args, pid=None)
