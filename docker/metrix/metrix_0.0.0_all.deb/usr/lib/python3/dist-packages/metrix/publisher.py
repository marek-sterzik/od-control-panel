from .message_type import message_type
from .schema import validate, validation
from schema import Optional, Or

class Publisher:
    def __init__(self, client):
        self.listener = None
        self.values = []
        self._consumed_values = {}
        self._full_values_cache = []
        self._client = client
        self._topic = "_publisher"
        self._class = "ui"
        self._consuming_state = 0
        self._client.register_message_consumer(self._accept_message)
    
    def set_publisher(self, topic):
        validate(validation.topic, topic)
        restart = self._consuming_state > 0 and (self._topic != topic)
        consume_values = self._consuming_state > 1
        if restart:
            self.stop_consume()
        self._topic = topic
        if restart:
            self.consume(consume_values)

    def set_class(self, value_class):
        validate(str, value_class)
        self._class = value_class
        self._update_values()
        self._update_consume_values()
    
    def publish(self, topic, classes = None, ui_config = None, publish_id = None):
        payload = self._get_payload(topic, classes, ui_config, publish_id)
        payload["operation"] = "publish"
        self._client.message(self._topic, payload)

    def unpublish(self, topic, classes = None, ui_config = None, publish_id = None):
        payload = self._get_payload(topic, classes, ui_config, publish_id)
        payload["operation"] = "unpublish"
        self._client.message(self._topic, payload)
    
    def unpublish_id(self, publish_id):
        payload = {"operation": "unpublish", "id": publish_id}
        self._client.message(self._topic, payload)

    def consume(self, consume_values = True):
        if self._consuming_state == 0:
            self._client.listen(message_type.BROADCAST, self._topic)
            self._client.query(self._topic)
        self._consuming_state = 2 if consume_values else 1
        self._update_consume_values()

    def stop_consume(self):
        if self._consuming_state > 0:
            self._client.unlisten(message_type.BROADCAST, self._topic)
            self._consuming_state = 0
        self._update_consume_values()

    def _accept_message(self, msg):
        if self._consuming_state <= 0:
            return False
        if msg.msg_type != message_type.BROADCAST:
            return False
        if msg.topic != self._topic:
            return False
        if msg.validate_payload([{"topic": validation.topic, object: object }], True):
            self._full_values_cache = msg.payload
            self._update_values()
            self._update_consume_values()
        return True

    def _update_consume_values(self):
        for topic in list(self._consumed_values.keys()):
            self._consumed_values[topic] = False
        if self._consuming_state >= 2:
            for value in self.values:
                topic = value["topic"]
                if topic not in self._consumed_values:
                    self._client.listen(message_type.BROADCAST, topic)
                    self._client.query(topic)
                self._consumed_values[topic] = True
        for topic in list(self._consumed_values.keys()):
            if not self._consumed_values[topic]:
                self._client.unlisten(message_type.BROADCAST, topic)
                del self._consumed_values[topic]


    def _update_values(self):
        values = []
        for value in self._full_values_cache:
            if value["classes"] is None or self._class in value["classes"]:
                values.append(value)
        if values != self.values:
            self.values = values
            if self.listener is not None:
                self.listener()

    def _get_payload(self, topic, classes, ui_config, publish_id):
        payload = {"topic": topic}
        if classes is not None:
            payload["classes"] = classes
        if ui_config is not None:
            payload["ui_config"] = ui_config
        if publish_id is not None:
            payload["id"] = publish_id
        return payload
        

