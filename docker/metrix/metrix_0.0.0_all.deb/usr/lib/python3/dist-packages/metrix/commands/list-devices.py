import re
from ..lib.devman import devman


help="list devices by type"
aliases=["l"]

def configure(parser):
    parser.add_argument("-S", "--serial", action="store_true", help="list serial devices")
    parser.add_argument("-U", "--usb", action="store_true", help="list usb devices only")
    parser.add_argument("device-query", nargs="*", help="device-query")

def print_table(table, columns):
    maxlen = {}
    for column in columns:
        if column not in maxlen:
            maxlen[column] = 0
        for line in table:
            maxlen[column] = max(maxlen[column], len(line[column]))
    for line in table:
        first = True
        for column in columns:
            print(f"{'' if first else ' '}{line[column]}{' ' * (maxlen[column] - len(line[column]))}", end="")
            first = False
        print("")
            

def format_device(dev):
    idquery = dev["idquery"] if dev['idquery'] is not None else ''
    query = dev["query"] if dev['query'] is not None else ''
    return {"type": dev["type"], "dev": dev["dev"], "idquery": idquery,"query": query}

natsort = lambda s: [int(t) if t.isdigit() else t.lower() for t in re.split(r'(\d+)', s)]

def strip_qm(query):
    if query[0:1] == '?':
        query = query[1:]
    return query

def invoke(args):
    device_class = []
    if args.serial:
        device_class.append(devman.SERIAL)
    queries = list(map(strip_qm, getattr(args, 'device-query')))
    if args.usb:
        queries.append("type=usb")
    query = "&".join(queries)

    if len(device_class) == 0:
        device_class.append(devman.ALL)
    devices = list(map(format_device, devman.qdevs(query, device_class)))
    devices.sort(key=lambda x: natsort(x["dev"]))
    print_table(devices, ["type", "dev", "idquery", "query"])
    return 0
