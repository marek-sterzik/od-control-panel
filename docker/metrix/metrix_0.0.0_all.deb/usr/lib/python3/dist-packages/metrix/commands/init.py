import os, re, sys
from ..project_template import list_templates, project_name_meta

help = "scaffold a new metrix experiment project"
aliases = ["i"]

def print_success(output_dir, tree):
    print()
    print("=" * 60)
    print("  Metrix experiment created!")
    print("=" * 60)
    print()
    print(f"  Location: {output_dir}")
    print()
    print("  Files created:")
    print()
    print(tree.tree("    "))
    print()
    print("  Next steps:")
    print()
    print(f"    cd {output_dir}")
    print("    metrix server -P .")
    print()
    print("  Or from the metrix-server root:")
    print()
    print(f"    metrix server -P {output_dir}")
    print()

def configure(parser):
    """Configure the argument parser for the ``init`` subcommand."""
    parser.add_argument(
        "-n", "--name", default=None, dest="project_name",
        help="Project name (default: interactive prompt)",
    )
    parser.add_argument(
        "-v", "--var", default=[], action="append", dest="variables",
        help="Put a variable (in the form '<var_name>=<value>')"
    )
    parser.add_argument(
        "-T", "--template", default=None,
        help="Template to use (default: experiment). "
             "Use --list-templates to see available options.",
    )
    parser.add_argument(
        "--non-interactive", action="store_true",
        help="Skip interactive prompts and use defaults",
    )
    parser.add_argument(
        "--list-templates", action="store_true",
        help="List available templates and exit",
    )
    parser.add_argument(
        "-f", "--force", action="store_true",
        help="Overwrite existing output directory",
    )
    parser.add_argument(
        "output", default=None, nargs="?",
        help="Output directory (default: ./<project-name>)",
    )

def invoke_list_templates(templates):
    print("Available templates:\n")
    for tpl in templates:
        default_mark = " [default]" if tpl.default() else ""
        description = tpl.description()
        variables = list(tpl.variables())
        print(f"  {tpl.name()}{default_mark}")
        print(f"    {description}")
        if len(variables) > 0:
            maxlen = max(0, *map(lambda v: len(v.name()), variables))
            print(f"    Variables:")
            for variable in variables:
                varhelp = variable.help()
                if varhelp is not None:
                    pad = " " * (maxlen - len(variable.name()))
                    varhelp = f"{pad} - {varhelp}"
                else:
                    varhelp = ""
                print(f"      {variable.name()}{varhelp}")
        print()

def prompt(label: str, default: str = "") -> str:
    """Ask the user for input with an optional default."""
    if default:
        prompt_text = f"{label} [{default}]: "
    else:
        prompt_text = f"{label}: "
    try:
        value = input(prompt_text).strip()
    except (EOFError, KeyboardInterrupt):
        print()
        sys.exit(1)
    if not value:
        value = default
    return value

def get_used_template_name(args, tpl_meta):
    template_name = args.template
    if template_name is None:
        template_name = tpl_meta["default"]
    if template_name is None:
        raise Exception("no tepmplate available")
    if template_name not in tpl_meta["templates"]:
        raise Exception(f"invalid template name: {template_name}")
    return template_name

def vars_to_dict(variables):
    dict_vars = {}
    for var in variables:
        parsed = var.split("=", 2)
        if len(parsed) != 2 or not re.match(r"^[a-z_][a-z0-9_]*$", parsed[0]):
            raise Exception(f"invalid variable definition: {var}")
        dict_vars[parsed[0]] = parsed[1]
    return dict_vars


def get_variable(var_meta, variables, cmdline_variables, args):
    var_name = var_meta.name()
    if var_name in cmdline_variables:
        try:
            var_meta.process(cmdline_variables[var_name], variables)
            return
        except Exception as e:
            default = cmdline_variables[var_name]
        if args.non_interactive:
            raise Exception(f"missing variable '{var_name}' in non-interactive mode")
    else:
        default = var_meta.default_value(variables)
    if default is None:
        default = ""
    else:
        default = str(default)
    
    while True:
        if args.non_interactive:
            value = default
        else:
            value = prompt(var_meta.prompt(), default)
        try:
            if value == "":
                raise Exception("input cannot be empty")
            var_meta.process(value, variables)
            return
        except Exception as e:
            if args.non_interactive:
                raise Exception(f"invalid input: {e}")
            print(f"Error: invalid input: {e}", file=sys.stderr)

def get_variables(template, cmdline_variables, args):
    variables = {"_output": args.output}
    get_variable(project_name_meta, variables, cmdline_variables, args)
    for var_meta in template.variables():
        get_variable(var_meta, variables, cmdline_variables, args)
    return variables

def invoke(args):
    templates = list_templates()
    if args.list_templates:
        invoke_list_templates(templates)
        return 0

    template = templates.get(args.template)

    cmdline_variables = vars_to_dict(args.variables)
    if args.project_name is not None:
        cmdline_variables["_project_name"] = args.project_name

    variables = get_variables(template, cmdline_variables, args)

    template_instance = template.instantiate(variables)
    
    output_dir = variables["_output"]
    
    tree = template_instance.populate_directory(output_dir, args.force)

    print_success(output_dir, tree)

    return 0
