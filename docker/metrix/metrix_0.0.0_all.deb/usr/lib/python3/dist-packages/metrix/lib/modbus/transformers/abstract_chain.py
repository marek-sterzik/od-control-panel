from .abstract import AbstractTransformer

class AbstractChainTransformer(AbstractTransformer):
    def get_read_operation(self):
        return self.chain.get_read_operation()

    def read_transform(self, value):
        return self.tr_read(self.chain.read_transform(value))

    def write_transform(self, value):
        return self.chain.write_transform(self.tr_write(value))

    def get_write_operation(self, value):
        return self.chain.get_write_operation(value)

    def tr_read(self, value):
        return value

    def tr_write(self, value):
        return value
