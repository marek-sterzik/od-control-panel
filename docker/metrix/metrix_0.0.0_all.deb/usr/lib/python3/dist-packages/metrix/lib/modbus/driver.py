from metrix.attrdict import attrdict
from .drivers import instantiate_driver, config_validation
from schema import And

class ModbusDriver:
    def __init__(self, config):
        self.driver = instantiate_driver(config)

    async def init(self):
        await self.driver.init()

    async def quit(self):
        await self.driver.quit()

    async def read(self, transformer, device, addr):
        operation = transformer.get_read_operation()
        if operation is not None:
            value = await operation(self.driver, device, addr)
        else:
            value = None
        return transformer.read_transform(value)

    async def write(self, transformer, device, addr, value):
        value = transformer.write_transform(value)
        operation = transformer.get_write_operation(value)
        if operation is not None:
            try:
                await operation(self.driver, device, addr)
            except Exception as e:
                raise Exception(f"cannot write value to modbus: {e}")

    validation = config_validation

