import sys
from datetime import datetime
from .attrdict import attrdict

levels = attrdict({
    "ERR": "error",
    "WARN": "warning",
    "MSG": "message",
    "DBG": "debug",
})

log_identifier = "???"

def identify_logs(identifier):
    global log_identifier
    log_identifier = identifier

def logger(msg, lev = levels.MSG):
    now = datetime.now().isoformat()
    print(f"{now}: [{log_identifier}] {lev.upper()}: {msg}", file=sys.stderr)
    sys.stderr.flush()

for i, v in levels.items():
    setattr(logger, i, v)
