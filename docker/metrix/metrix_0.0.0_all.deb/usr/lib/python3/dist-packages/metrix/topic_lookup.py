class topic_lookup:
    def __init__(self):
        self.topics = {}
        self.objects = {}

    def add(self, topic, obj):
        doAdd = False
        if not (obj in self.objects):
            self.objects[obj] = {}
        if not (topic in self.objects[obj]):
            self.objects[obj][topic] = 0
            doAdd = True
        self.objects[obj][topic] +=1

        if doAdd:
            if not (topic in self.topics):
                self.topics[topic] = []
            if not (obj in self.topics[topic]):
                self.topics[topic].append(obj)
        
        return self

    def remove(self, topic, obj):
        doRemove = False
        if (obj in self.objects) and (topic in self.objects[obj]):
            self.objects[obj][topic] -= 1
            if self.objects[obj][topic] <= 0:
                doRemove = True
                del self.objects[obj][topic]
                if len(self.objects[obj]) == 0:
                    del self.objects[obj]
        
        if doRemove:
            self.topics[topic].remove(obj)
            if len(self.topics[topic]) == 0:
                del self.topics[topic]
        return self

    def remove_all(self, obj):
        if obj in self.objects:
            for topic in list(self.objects[obj].keys()):
                self.topics[topic].remove(obj)
                if len(self.topics[topic]) == 0:
                    del self.topics[topic]
            del self.objects[obj]
        return self

    def is_empty(self):
        return len(self.objects) == 0

    def get_objects(self, topic):
        if topic in self.topics:
            return self.topics[topic].copy()
        else:
            return []


class type_topic_lookup:
    def __init__(self):
        self.types = {}

    def add(self, msg_type, topic, obj):
        if not (msg_type in self.types):
            self.types[msg_type] = topic_lookup()
        self.types[msg_type].add(topic, obj)
        return self
    
    def remove(self, msg_type, topic, obj):
        if (msg_type in self.types):
            self.types[msg_type].remove(topic, obj)
            if self.types[msg_type].is_empty():
                del self.types[msg_type]
        return self

    def remove_all(self, obj):
        for msg_type in list(self.types.keys()):
            self.types[msg_type].remove_all(obj)
            if self.types[msg_type].is_empty():
                del self.types[msg_type]
        return self        

    def get_objects(self, msg_type, topic):
        if (msg_type in self.types):
            return self.types[msg_type].get_objects(topic)
        else:
            return []
