"""Template registry — maps template names to metadata.

Each entry describes:
    - description   human-readable summary
    - default       whether this is the default template
    - variables     list of variable names expected/used by the template
"""

from ..attrdict import attrdict
from ..template_variable_types import var_types
from ..schema import validation

variables = attrdict({
    "package": {
        "name": "package",
        "help": "Project package name (python root package)",
        "prompt": "Enter project package name (python root package)",
        "default": lambda variables: variables.get("_project_name_slug", "my_project"),
        "type": var_types.validator(validation.package),
    },
})

TEMPLATES_META = {
    "metrix-project": {
        "description": "Minimal metrix experiment",
        "default": True,
        "variables": [
            variables.package,
        ],
    },
}
