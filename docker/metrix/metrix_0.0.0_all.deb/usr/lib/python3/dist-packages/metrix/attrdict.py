class attrdict(dict):
    def __init__(self, initial_values = {}):
        for i, v in initial_values.items():
            self[i] = v
    def __getattr__(self, key):
        return self[key]
