from .schema import check, validation
import json

def arg_from_json(arg):
    try:
        return json.loads(arg)
    except:
        return arg

def process_name_from_json(process):
    if check(validation.module, process):
        return process
    p2 = arg_from_json(process)
    if p2 != process and check(validation.module, p2):
        return p2
    raise Exception(f"expected process module name: '{process}'")

def parse_process_arguments(process, process_arguments):
    process_part = [process_name_from_json(process)] if process is not None else []
    return process_part + list(map(arg_from_json, process_arguments))

def get_pid(pid):
    if check(validation.pid, pid):
        return pid
    raise Exception("PID string expected in --pid option argument")

def get_topic(topic):
    if check(validation.topic, topic):
        return topic
    raise Exception(f"invalid topic: '{topic}'")
