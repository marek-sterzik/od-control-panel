import asyncio, sys, inspect
from .logger import logger

async def asasync(ret):
    if inspect.isawaitable(ret):
        ret = await ret
    return ret

async def loop_process(functions, client):
    while True:
        await asasync(functions["loop"]())
        await client.flush()
        await client.loop_wait()

async def wait_quit(functions, client):
    await client._quit_event.wait()
    await asasync(functions["quit"]())

async def async_process(functions, client):
    ret = await functions["async_process"]()
    client.terminate(ret)

async def main_process(functions, client):
    if functions["init"] is not None:
        await client._configure_handshake(True)
        await asasync(functions["init"]())
        await client.flush()
    await client._configure_handshake(False)
    coros = []
    if functions["async_process"] is not None:
        coros.append(async_process(functions, client))
    if functions["loop"] is not None:
        coros.append(loop_process(functions, client))

    coros.append(wait_quit(functions, client))

    ret = await asyncio.gather(*coros)

    return ret[0]

def do_quit_module(client):
    client.terminate()

MODULE_FUNCTIONS = ["init", "async_process", "loop", "recv", "core_recv", "quit", "cleanup"]

def module_processor(module, client):
    module_functions = {}
    for fn in MODULE_FUNCTIONS:
        module_fn = "metrix_" + fn
        if hasattr(module, module_fn):
            module_functions[fn] = getattr(module, module_fn)
        else:
            module_functions[fn] = None

    if module_functions["quit"] is None:
        module_functions["quit"] = lambda: do_quit_module(client)

    if module_functions["recv"] is not None:
        recv_fn = module_functions["recv"]
        module_functions["recv"] = lambda msg: asasync(recv_fn(msg))

    if module_functions["core_recv"] is not None:
        core_recv_fn = module_functions["core_recv"]
        module_functions["core_recv"] = lambda msg: asasync(core_recv_fn(msg))

    module_functions["main_process"] = lambda: main_process(module_functions, client)

    return module_functions
