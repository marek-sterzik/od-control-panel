import asyncio, sys, os, traceback, signal
from .schema import validation, validate
from schema import Or, Optional
from websockets.asyncio.server import serve
from .message import message
from .message_type import message_type, message_type_shortcuts, hr_message_types
from .process_state import process_state
from .signals import signals
from .topic_lookup import type_topic_lookup
from .random_id import random_id
from .procutils import process_start, process_wait
from .logger import logger, identify_logs
from .server_state import server_state
from .triggers import Triggers, TriggerDescriptor
from .routed_message import RoutedMessage

class TerminateException(Exception):
    pass

def get_expected_process_state_after_handshake(current_process_state, wanted_process_state):
    if current_process_state not in [process_state.CREATED, process_state.CONFIGURING]:
        return current_process_state
    if wanted_process_state not in [process_state.CONFIGURING, process_state.RUNNING]:
        return current_process_state
    return wanted_process_state

def is_handled_pid(ws_pid, handled_pids):
    if ws_pid is None:
        return False
    return ws_pid in handled_pids


class CoreFunctions:
    def __init__(self, server):
        self.server = server
        self.port = None

    def ping(self, websocket, msg):
        return [msg]

    def listen(self, websocket, msg):
        msg.validate_payload({
            "msg_type": validation.msg_type,
            "topic": validation.topic,
        })
        if msg.payload["msg_type"] != message_type.CORE:
            self.server.tt_lookup.add(msg.payload["msg_type"], msg.payload["topic"], websocket)
        return []

    def unlisten(self, websocket, msg):
        msg.validate_payload({
            "msg_type": validation.msg_type,
            "topic": validation.topic,
        })
        if msg.payload["msg_type"] != message_type.CORE:
            self.server.tt_lookup.remove(msg.payload["msg_type"], msg.payload["topic"], websocket)
        return []

    def quit(self, websocket, msg):
        pid = self.server.get_attr(websocket, "pid")
        if pid is not None and pid in self.server.processes:
            if self.server.processes[pid]["state"] == process_state.RUNNING:
                self.server.processes[pid]["state"] = process_state.QUITTING
                return [self.server.proc_message(pid, process_state.QUITTING)]
        return []

    def register(self, websocket, msg):
        msg.validate_payload({Optional("pid"): Or(None, validation.pid), Optional("configuring"): bool})
        payload = msg.payload
        if "pid" not in payload:
            payload["pid"] = None
        if "configuring" not in payload:
            payload["configuring"] = False

        pid = payload["pid"]
        msgs = []
        msgs.append(message(
            message_type.CORE,
            "register",
            {"config": self.server.get_config_for(websocket)},
            msg.reference
        ))
        if pid is not None:
            if pid not in self.server.processes or \
                (self.server.processes[pid]["websocket"] is not None and self.server.processes[pid]["websocket"] != websocket):
                self.server.set_attr(websocket, "running", False)
                return []
            self.server.processes[pid]["websocket"] = websocket
            new_process_state = get_expected_process_state_after_handshake(
                self.server.processes[pid]["state"],
                process_state.CONFIGURING if payload["configuring"] else process_state.RUNNING
            )
            if new_process_state != self.server.processes[pid]["state"]:
                self.server.processes[pid]["state"] = new_process_state
                msgs.append(self.server.proc_message(pid, new_process_state))
            self.server.set_attr(websocket, "pid", pid)
        return msgs
    
    def plugins(self, websocket, msg):
        msg.validate_payload({
            "plugins": validation.plugins,
            Optional("libs"): [str],
        })
        plugins = msg.payload["plugins"]
        libs = msg.payload["libs"] if "libs" in msg.payload else []
        asyncio.create_task(self.server.load_plugins(plugins, libs, websocket, msg.reference))
        return []


    def start(self, websocket, msg):
        msg.validate_payload({
            Optional("pid"): Or(None, validation.pid),
            "module": validation.module,
            Optional("args"): [object],
            Optional("libs"): [str],
        })
        payload = msg.payload
        if "pid" not in payload or payload["pid"] is None:
            payload["pid"] = random_id("p")
        if "args" not in payload:
            payload["args"] = []
        if "libs" not in payload:
            payload["libs"] = []
        
        pid = payload["pid"]
        msg = self.server.start_process(payload["module"], payload["args"], payload["pid"], payload["libs"], False)
        return [msg] if msg is not None else []

    def signal(self, websocket, msg):
        msg.validate_payload({
            "pid": validation.pid,
            "signal": validation.signal,
        })
        payload = msg.payload
        pid = payload["pid"]
        if pid not in self.server.processes:
            return []
        websocket = self.server.processes[pid]["websocket"]
        if websocket is None:
            return []
        if payload["signal"] == signals.QUIT:
            return [RoutedMessage(message(message_type.CORE, "quit"), [websocket])]
        elif payload["signal"] == signals.TERMINATE:
            self.server.set_attr(websocket, "running", False)
            asyncio.create_task(websocket.close())
            return [RoutedMessage(message(message_type.CORE, "terminate"), [websocket])]
        else:
            raise Exception(f"Trying to send an unknown signal: {payload['signal']}")

    def trigger(self, websocket, msg):
        msg.validate_payload({
            "module": validation.module,
            Optional("args"): Or(None, [object]),
            Optional("libs"): [str],
            "topics": [Or(
                validation.topic_pattern,
                {
                    "topic": validation.topic_pattern,
                    Optional("msg_types"): Or(
                        None,
                        validation.enum(*message_type_shortcuts.keys()),
                        [validation.msg_type],
                    )
                }
            )],
            Optional("id"): Or(None, validation.pid),
        })
        payload = msg.payload
        id = payload.get("id", None)
        module = payload.get("module")
        arguments = payload.get("args", None)
        libs = payload.get("libs", [])
        if arguments is None:
            arguments = []
        topics = []
        for t in payload.get("topics"):
            if isinstance(t, str):
                t = {"topic": t}
            msg_types = t.get("msg_types", None)
            if msg_types is None:
                msg_types = "write"
            if isinstance(msg_types, str):
                msg_types = message_type_shortcuts.get(msg_types).copy()
            t["msg_types"] = msg_types
            topics.append(t)

        trigger = TriggerDescriptor()
        trigger.set_id(id)
        trigger.set_module(module)
        trigger.set_arguments(arguments)
        trigger.set_libs(libs)
        for t in topics:
            trigger.add_trigger(t["topic"], t["msg_types"])

        try:
            self.server.triggers.add_trigger(trigger)
        except Exception as e:
            logger(f"registering trigger failed: {e}", lev=logger.ERR)
            return []
        topics = ", ".join(map(lambda t: t["topic"] + "[" + hr_message_types(t["msg_types"]) + "]", topics))
        as_id=""
        if id is not None:
            as_id=f" as '{id}'"
        logger(f"registered trigger for topics {topics} to [{module}]{as_id}", lev=logger.MSG)
        return []

    def rmtrigger(self, websocket, msg):
        msg.validate_payload({
            "id": validation.pid,
        })
        id = msg.payload["id"]
        try:
            self.server.triggers.remove_trigger(id)
        except Exception as e:
            logger(f"unregistering trigger failed: {e}", lev=logger.ERR)
            return []
        logger(f"removed trigger '{id}'")
        return []
        

class MetrixServer:
    def __init__(self):
        self.state = server_state.STARTING
        self.tt_lookup = type_topic_lookup()
        self.core_functions = CoreFunctions(self)
        self.client_attrs = {}
        self.processes = {}
        self.process_handles = {}
        self.exception_queue = asyncio.Queue()
        self.quit_event = asyncio.Event()
        self.libs = []
        self.terminate_timeout = None
        self.persist = False
        self.triggers = Triggers(self)
        self.plugins_loaded = asyncio.Event()
        self.plugins_wait = asyncio.Event()
        self.plugins_loaded.set()
        self.config = {}

    def get_libs(self, additional_libs = []):
        libs = self.libs.copy()
        for lib in additional_libs:
            if os.path.isdir(lib):
                libs.append(os.path.realpath(lib))
        return libs
            
    def set_attr(self, websocket, attr, value):
        if not (websocket in self.client_attrs):
            self.client_attrs[websocket] = {}
        self.client_attrs[websocket][attr] = value
    
    def get_attr(self, websocket, attr):
        if (websocket in self.client_attrs) and (attr in self.client_attrs[websocket]):
            return self.client_attrs[websocket][attr]
        return None

    def clear_attrs(self, websocket):
        if (websocket in self.client_attrs):
            del self.client_attrs[websocket]

    def get_local_url(self):
        return f"ws://localhost:{self.port}"

    def get_config_for(self, websocket):
        return self.config

    def proc_message(self, pid, status, record = None):
        if record is None:
            if pid in self.processes:
                record = self.processes[pid]
            else:
                record = {"module": "???", "quiet": True, "ev_fin": None}

        if not record["quiet"] or self.state.is_quitting():
            self.state = self.state.invoke_transition(status, bool(self.processes), self)
        if not record["quiet"]:
            logger(f"process {pid} [{record['module']}] changed state to {status.upper()}", lev=logger.MSG)
        if record["ev_fin"] is not None and status in [process_state.DISCONNECTED, process_state.TERMINATED, process_state.NOT_RUNNING]:
            record["ev_fin"].set()
        return message(message_type.PROCESS, pid, status)

    def quit(self):
        self.state = self.state.transit_to_quit(self)

    def terminate(self):
        self.state = self.state.transit_to_terminate(self)

    def sigint(self):
        print("", file=sys.stderr)
        if not self.state.is_terminating():
            if self.state.is_quitting():
                self.terminate()
            else:
                self.quit()

    def terminate_signal(self):
        self.exception_queue.put_nowait(TerminateException())

    def quit_signal(self):
        self.quit_event.set()

    async def load_plugins(self, plugins, libs, websocket, msg_reference):
        await self.plugins_loaded.wait()
        self.plugins_loaded.clear()
        pid = random_id("P")
        self.start_process("metrix.proc.plugin", plugins, pid, libs, True)
        if pid in self.processes:
            event = self.processes[pid]["ev_fin"]
            if event is not None:
                await event.wait()
        self.plugins_loaded.set()
        self.plugins_wait.set()
        if websocket is not None:
            msg = message(message_type.CORE, "plugins", None, msg_reference)
            await self.send_single_message(msg, websocket)
            

    async def handle_core_message(self, websocket, msg):
        try:
            if msg.topic[0:1] == "_":
                return []
            if hasattr(self.core_functions, msg.topic):
                return getattr(self.core_functions, msg.topic)(websocket, msg)
            return []
        except (KeyboardInterrupt, asyncio.CancelledError):
            raise
        except Exception as e:
            traceback.print_exc(file=sys.stderr)
            return []
    
    def start_process(self, module, args, pid, libs, plugin_loader):
        if pid not in self.processes:
            self.processes[pid] = {
                "pid": pid,
                "state": process_state.CREATED,
                "websocket": None,
                "module": module,
                "quiet": plugin_loader,
                "ev_fin": asyncio.Event() if plugin_loader else None,
            }
            ph = process_start(
                pid,
                module,
                args,
                self.get_local_url(),
                self.get_libs(libs)
            )
            if ph is None:
                del self.processes[pid]
        else:
            logger(f"trying to start a process with an already existing pid: {pid}, ignoring request", lev=logger.ERR)
            return None
        if ph is not None:
            self.process_handles[ph] = pid
        return self.proc_message(pid, process_state.CREATED if ph is not None else process_state.TERMINATED)

    async def handle_proc_query(self, websocket, msg):
        pid = msg.topic
        if "." not in pid and pid in self.processes:
            status = self.processes[pid].get("state", process_state.NOT_RUNNING)
        else:
            status = process_state.NOT_RUNNING
        return [message(message_type.PROCESS, pid, status, msg.reference)]


    async def send_single_message(self, msg, websocket):
        try:
            await websocket.send(msg.to_string())
        except asyncio.CancelledError:
            raise
        except:
            pass

    def get_routed_message_websockets(self, msg):
        if len(msg.pids) == 0:
            return msg.websockets

        pid_websockets = []
        for pid in msg.pids:
            if pid in self.processes:
                pid_websockets.append(self.processes[pid]["websocket"])
            
        return msg.websockets + pid_websockets

    async def broadcast_message(self, msg, originating_websocket = None):
        if isinstance(msg, RoutedMessage):
            websockets = self.get_routed_message_websockets(msg)
            msg = msg.msg
        elif msg.msg_type == message_type.CORE:
            if originating_websocket != None:
                websockets = [originating_websocket]
            else:
                websockets = []
        else:
            handled_pids = await self.triggers.consume_message(msg)
            websockets = list(
                filter(
                    lambda ws: not is_handled_pid(self.get_attr(ws, "pid"), handled_pids),
                    self.tt_lookup.get_objects(msg.msg_type, msg.topic)
                )
            )
        if len(websockets) > 0:
            coroutines = map(lambda ws: self.send_single_message(msg, ws), websockets)
            await asyncio.gather(*coroutines)
    
    async def disconnect_socket(self, websocket):
        pid = self.get_attr(websocket, "pid")
        if pid is not None and pid in self.processes:
            self.processes[pid]["state"] = process_state.DISCONNECTED
            await self.broadcast_message(self.proc_message(pid, process_state.DISCONNECTED))
            

    async def websocket_handler(self, websocket):
        try:
            self.set_attr(websocket, "running", True)
            self.set_attr(websocket, "pid", None)
            async for msg in websocket:
                msg = message.from_string(msg)
                if msg == None:
                    continue
                if msg.msg_type == message_type.CORE:
                    msgs = await self.handle_core_message(websocket, msg)
                elif msg.msg_type == message_type.PROCESS:
                    msgs = await self.handle_proc_query(websocket, msg)
                else:
                    msgs = [msg]
                for msg in msgs:
                    await self.broadcast_message(msg, websocket)
                if not self.get_attr(websocket, "running"):
                    break
        finally:
            await self.disconnect_socket(websocket)
            self.tt_lookup.remove_all(websocket)
            self.clear_attrs(websocket)
    
    async def websocket_handler_except(self, websocket):
        try:
            await self.websocket_handler(websocket)
        except (KeyboardInterrupt) as e:
            self.exception_queue.put_nowait(e)

    async def wait_pids(self):
        while True:
            ph = await process_wait(self.process_handles.keys())
            if (ph in self.process_handles):
                pid = self.process_handles[ph]
                del self.process_handles[ph]
                record = self.processes[pid]
                del self.processes[pid]
                await self.broadcast_message(self.proc_message(pid, process_state.TERMINATED, record))

    async def handle_exceptions(self):
        raise await self.exception_queue.get()
    
    async def handle_external_message(self, msg):
        msgs = await self.handle_core_message(None, msg)
        for msg in msgs:
            await self.broadcast_message(msg, None)

    async def invoke_start(self, init_process, plugins):
        if len(plugins) > 0:
            msg = message(message_type.CORE, "plugins", {"plugins": plugins})
            self.plugins_wait.clear()
            await self.handle_external_message(msg)
            logger("loading plugins")
            await self.plugins_wait.wait()
            logger("plugins loaded")
            
        if (init_process is not None) and len(init_process) > 0:
            msg = message(message_type.CORE, "start", {"module": init_process[0], "args": init_process[1:]})
            await self.handle_external_message(msg)

    async def invoke_control(self):
        await self.quit_event.wait()
        
        msg = message(message_type.CORE, "quit")
        coroutines = list(map(lambda ws: self.send_single_message(msg, ws), self.client_attrs.keys()))
        if len(coroutines) > 0:
            await asyncio.gather(*coroutines)

        if not bool(self.processes):
            self.terminate()
            return
        
        if self.terminate_timeout is not None and self.terminate_timeout > 0:
            await asyncio.sleep(self.terminate_timeout)
            self.terminate()


    async def main(self, listen_ip, listen_port, init_process, plugins):
        async with serve(self.websocket_handler_except, listen_ip, listen_port) as server:
            await asyncio.gather(
                server.serve_forever(),
                self.wait_pids(),
                self.handle_exceptions(),
                self.invoke_start(init_process, plugins),
                self.invoke_control()
            )

    def run(self, listen_ip = "0.0.0.0", listen_port = 8765, init_process = None, plugins = [], libs = [], config = {}, persist = False, terminate_timeout = None):
        signal.signal(signal.SIGINT, lambda sig, frame: self.sigint())
        identify_logs(__name__)
        self.port = listen_port
        self.libs = libs
        self.persist = persist
        self.terminate_timeout = terminate_timeout
        self.config = config
        ret = 1
        try:
            asyncio.run(self.main(listen_ip, listen_port, init_process, plugins))
        except KeyboardInterrupt:
            print("", file=sys.stderr)
        except TerminateException:
            ret = 0
        finally:
            self.state = server_state.TERMINATED
        sys.exit(ret)

server = MetrixServer()
