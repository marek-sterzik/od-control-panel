def metrix_plugin(plugin):
    plugin.depends("metrix.plugin.publisher", publish_args=True)
    plugin.depends("metrix.plugin.modbus", publish_args=True)
    plugin.depends("metrix.plugin.timer", publish_args=True)
