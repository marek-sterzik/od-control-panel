import asyncio, os, aiohttp
from aiohttp import web
from datetime import datetime
from metrix import client, message_type, logger, validation
from metrix.webdir import webdir
from metrix.message import message
from metrix.router import Router

async def sender(msg, ws):
    try:
        await ws.send_str(msg.to_string())
    except (KeyboardInterrupt, asyncio.CancelledError):
        raise
    except:
        pass

router = Router(client, sender)

class UserInterface:
    def __init__(self, config):
        pass

    async def main(self, rq):
        return web.FileResponse(os.path.join(webdir, "index.html"))

    async def websocket(self, rq):
        ws = web.WebSocketResponse()
        await ws.prepare(rq)

        await router.connect_client(ws)

        async for wsmsg in ws:
            if wsmsg.type == aiohttp.WSMsgType.TEXT:
                msg = message.from_string(wsmsg.data)
                if msg is not None and self.message_allowed(msg):
                    await router.message_from_client(msg, ws)

        await router.disconnect_client(ws)
        return ws

    def message_allowed(self, msg):
        return True

class NullUserInterface:
    def __init__(self):
        pass

    async def main(self, rq):
        return web.Response(text="404 Not found", status=404)

    async def websocket(self, rq):
        return self.main(rq)

class RedirectUserInterface:
    def __init__(self, main_instance):
        self.main_instance = main_instance

    async def main(self, rq):
        return web.HTTPFound(f'/i/{self.main_instance}/')

    async def websocket(self, rq):
        return web.HTTPFound(f'/i/{self.main_instance}/websocket')


class UserInterfaces:
    def __init__(self):
        self.interfaces = {}
        self.default = None
        self.default_set = False

    def add(self, config, name, aliases = [], default = False):
        if name in self.interfaces:
            raise Exception(f"user interface name '{name}' already in use")
        for alias in aliases:
            if alias in self.interfaces:
                raise Exception(f"user interface alias '{name}' already in use")
        if default and self.default_set:
            raise Exception(f"default user interface already defined")

        if self.default is None or default:
            self.default = name
            if default:
                self.default_set = True

        self.interfaces[name] = UserInterface(config)
        for alias in aliases:
            self.interfaces[alias] = RedirectUserInterface(name)

    def get_interface(self, name):
        if name in self.interfaces:
            return self.interfaces[name]
        return NullUserInterface()


interfaces = UserInterfaces()
interfaces.add({}, "main", ["master"], True)

async def main_redirect(rq):
    if interfaces.default is not None:
        return web.HTTPFound(f"/i/{interfaces.default}/")
    return web.Response(text="webui not configured", status=404)

def app():
    app = web.Application()
    app.add_routes([
        web.get('/', main_redirect),
        web.get('/i/{instance}', lambda rq: web.HTTPFound(f"/i/{rq.match_info['instance']}/")),
        web.get('/i/{instance}/', lambda rq: interfaces.get_interface(rq.match_info["instance"]).main(rq)),
        web.get('/i/{instance}/websocket', lambda rq: interfaces.get_interface(rq.match_info["instance"]).websocket(rq)),
        web.static('/static', os.path.join(webdir, "static")),
    ])
    return app

async def metrix_recv(msg):
    await router.message_from_server(msg)

async def metrix_init():
    asyncio.create_task(web._run_app(app(), port=8888, print=None))
