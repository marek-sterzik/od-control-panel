from ..process_arguments import parse_process_arguments, get_pid
from ..message_type import message_type

from pprint import pprint

help="run process using metrix server"
aliases=["r"]

def configure(parser):
    parser.add_argument("-p", "--pid", default=None, help="set PID string of the metrix process")
    parser.add_argument("process", nargs="?", help="process module id to be started")
    parser.add_argument("process-arguments", nargs="*", help="process arguments")

def invoke(args):
    pid = None
    if args.pid is not None:
        pid = get_pid(args.pid)
    process = parse_process_arguments(args.process, getattr(args, "process-arguments"))
    if len(process) > 0:
        module = "metrix.proc.send_message"
        payload = {"module": process[0], "args": process[1:], "pid": pid, "libs": args.lib}
        process_args = [message_type.CORE, "start", payload]
        from ..client import client
        return client.run(module=module, server_url=args.url, arguments=process_args, pid=None)
    else:
        raise Exception("missing process to start")
