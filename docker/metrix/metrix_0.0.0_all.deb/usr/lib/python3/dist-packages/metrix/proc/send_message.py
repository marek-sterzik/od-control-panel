import sys, asyncio
from metrix import client, check
from metrix.message import message

wait_event = asyncio.Event()
wait_event.clear()

async def metrix_async_process():
    if len(client.arguments) < 2 or len(client.arguments) > 5:
        print(
            f"send_message: expected 2 or 3 arguments [msg_type, topic] or "
            f"[msg_type, topic, payload], got {len(client.arguments)}",
            file=sys.stderr,
        )
        return 1

    msg_type = client.arguments[0]
    topic = client.arguments[1]
    payload = client.arguments[2] if len(client.arguments) >= 3 else None
    reference = client.arguments[3] if len(client.arguments) >= 4 else None
    attrs = client.arguments[4] if len(client.arguments) >=5 else {}

    wait_for_plugin = attrs.get("wait_for_plugin", False)
    if not check(bool, wait_for_plugin):
        wait_for_plugin = False

    try:
        client.send(msg_type, topic, payload, reference)
        if wait_for_plugin:
            await wait_event.wait()
    except Exception as e:
        print(f"send_message: {e}", file=sys.stderr)
        return 1
    return 0


def metrix_core_recv(msg):
    if msg.match("plugins@core"):
        wait_event.set()
