def metrix_plugin(plugin):
    publisher_topic = plugin.arg("publisher_topic", "_publisher")
    plugin.trigger([{"topic": publisher_topic, "msg_types": "write"}], "metrix.proc.publisher", [{"publisher_topic": publisher_topic}])

