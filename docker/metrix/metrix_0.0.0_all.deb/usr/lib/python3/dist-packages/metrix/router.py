import asyncio
from .topic_lookup import type_topic_lookup
from .message_type import message_type
from .schema import validation
from .message import message
from .random_id import random_id

class Router:
    def __init__(self, client, sender):
        self.client = client
        self.sender = sender
        self.tt_lookup = type_topic_lookup()
        self.client_objects = {}
        self.client_object_ids = {}

    async def message_from_client(self, msg, client_object):
        msg = await self.handle_from_client(msg, client_object)
        if msg is not None:
            self.client.put_message(msg)
            await self.client.flush()

    async def disconnect_client(self, client_object):
        if client_object in self.client_objects:
            id = self.client_objects[client_object]["id"]
            listeners = self.client_objects[client_object]["listeners"]
            del self.client_object_ids[id]
            del self.client_objects[client_object]
            self.tt_lookup.remove_all(client_object)
            for msg_type, mt_listeners in listeners.items():
                for topic, cnt in mt_listeners.items():
                    if cnt <= 0:
                        continue
                    self.client.put_message(message(message_type.CORE, "unlisten", {"msg_type": msg_type, "topic": topic}))
            await self.client.flush()

    async def connect_client(self, client_object):
        self.put_client_object(client_object)

    async def message_from_server(self, msg):
        if msg.has_type(message_type.CORE):
            msg, client_objs = self.handle_core_from_server(msg)
        elif msg.has_type(message_type.PROCESS):
            msg, client_objs = self.handle_process_from_server(msg)
        else:
            msg, client_objs = self.handle_ordinary_from_server(msg)
            
        if msg is not None and len(client_objs) > 0:
            coroutines = map(lambda co: self.sender(msg, co), client_objs)
            await asyncio.gather(*coroutines)
            

    async def handle_from_client(self, msg, client_object):
        if msg.has_type(message_type.CORE):
            return await self.handle_core_from_client(msg, client_object)
        elif msg.has_type(message_type.PROCESS):
            reference = self.create_reference(client_object, msg.reference)
            return message(msg.msg_type, msg.topic, msg.payload, reference)
        else:
            return msg

    def put_client_object(self, client_object):
        if client_object not in self.client_objects:
            id = random_id("r")
            self.client_objects[client_object] = {"id": id, "listeners": {}}
            self.client_object_ids[id] = client_object
    
    def create_reference(self, client_object, original_reference):
        self.put_client_object(client_object)
        return f"{self.client_objects[client_object]["id"]}:{original_reference}"

    async def handle_core_from_client(self, msg, client_object):
        if msg.topic in ["listen", "unlisten"]:
            valid = msg.check_payload({
                "msg_type": validation.msg_type,
                "topic": validation.topic,
            })
            if valid:
                self.put_client_object(client_object)
                if msg.topic == "listen":
                    return self.listen(client_object, msg.payload["msg_type"], msg.payload["topic"])
                else:
                    return self.unlisten(client_object, msg.payload["msg_type"], msg.payload["topic"])
            return None
        elif msg.topic in ["ping", "plugins"]:
            reference = self.create_reference(client_object, msg.reference)
            return message(msg.msg_type, msg.topic, msg.payload, reference)
        elif msg.topic == "quit":
            return None
        elif msg.topic == "register":
            ret_msg = message(message_type.CORE, "register", {}, msg.reference)
            await self.sender(ret_msg, client_object)
            return None
        elif msg.topic in ["start", "signal", "trigger", "rmtrigger"]:
            return msg
        return None

    def handle_core_from_server(self, msg):
        if msg.topic in ["ping", "plugins"]:
            client_object, new_reference = self.parse_reference(msg.reference)
            if new_reference != msg.reference:
                msg = message(msg.msg_type, msg.topic, msg.payload, new_reference)
            if client_object is not None:
                return msg, [client_object]
            else:
                return None, []
        elif msg.topic == "quit":
            return msg, list(self.client_objects.keys())
        else:
            return None, []

    def handle_process_from_server(self, msg):
        if msg.reference != "":
            client_object, new_reference = self.parse_reference(msg.reference)
            if new_reference != msg.reference:
                msg = message(msg.msg_type, msg.topic, msg.payload, new_reference)
        if client_object is not None:
            return msg, [client_object]
        return self.handle_ordinary_from_server(msg)

    def parse_reference(self, reference):
        parsed = reference.split(":", 2)
        if len(parsed) != 2:
            return None, reference
        id = parsed[0]
        if id in self.client_object_ids:
            return self.client_object_ids[id], parsed[1]
        else:
            return None, reference

    def handle_ordinary_from_server(self, msg):
        return msg, self.tt_lookup.get_objects(msg.msg_type, msg.topic)
                    
    def listen(self, client_object, msg_type, topic):
        listeners = self.client_objects[client_object]["listeners"]
        if msg_type not in listeners:
            listeners[msg_type] = {}
        msg = None
        if topic not in listeners[msg_type]:
            listeners[msg_type][topic] = 0
            self.do_listen(client_object, msg_type, topic)
            msg = message(message_type.CORE, "listen", {"msg_type": msg_type, "topic": topic})
        listeners[msg_type][topic] += 1
        return msg

    def unlisten(self, client_object, msg_type, topic):
        listeners = self.client_objects[client_object]["listeners"]
        msg = None
        if msg_type in listeners and topic in listeners[msg_type]:
            listeners[msg_type][topic] -= 1
            if listeners[msg_type][topic] <= 0:
                self.do_unlisten(client_object, msg_type, topic)
                msg = message(message_type.CORE, "unlisten", {"msg_type": msg_type, "topic": topic})
                del listeners[msg_type][topic]
                if not bool(listeners[msg_type]):
                    del listeners[msg_type]
        return msg    

    def do_listen(self, client_object, msg_type, topic):
        self.tt_lookup.add(msg_type, topic, client_object)

    def do_unlisten(self, client_object, msg_type, topic):
        self.tt_lookup.remove(msg_type, topic, client_object)
