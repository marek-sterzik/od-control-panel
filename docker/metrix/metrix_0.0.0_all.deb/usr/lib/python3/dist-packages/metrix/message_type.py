from .attrdict import attrdict

message_type = attrdict()
message_type["CORE"] = "core"
message_type["BROADCAST"] = "broadcast"
message_type["QUERY"] = "query"
message_type["WRITE"] = "write"
message_type["ERROR"] = "error"
message_type["MESSAGE"] = "message"
message_type["PROCESS"] = "process"

message_type_short = {
    message_type.CORE: "c",
    message_type.BROADCAST: "b",
    message_type.QUERY: "q",
    message_type.WRITE: "w",
    message_type.ERROR: "e",
    message_type.MESSAGE: "m",
    message_type.PROCESS: "p",
}

message_type_shortcuts = {
    "all": [message_type.BROADCAST, message_type.QUERY, message_type.WRITE, message_type.ERROR, message_type.MESSAGE],
    "read": [message_type.BROADCAST, message_type.ERROR],
    "write": [message_type.QUERY, message_type.WRITE, message_type.MESSAGE],
}

def hr_message_types(msg_types):
    out = ""
    msg_types = {x: True for x in msg_types}
    for name, types in message_type_shortcuts.items():
        all_ok = True
        for msg_type in types:
            if msg_type not in msg_types:
                all_ok = False
                break
        if all_ok:
            for msg_type in types:
                del msg_types[msg_type]
            out += name[0].upper()

    for msg_type, short in message_type_short.items():
        if msg_type in msg_types:
            out += short
    
    if out == "":
        out = "N"
    return out
    
