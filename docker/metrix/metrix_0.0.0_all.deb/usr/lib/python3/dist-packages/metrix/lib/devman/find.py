import re
from .query import query_device

def find_device(descriptor, device_class):
    if re.match(r'\?', descriptor):
        descriptor = descriptor[1:]
        if re.match(r'\?', descriptor):
            return descriptor
        dev = query_device(descriptor, device_class)
        return dev["dev"]
    else:    
        return descriptor


