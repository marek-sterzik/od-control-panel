#!/usr/bin/python

import os, stat, glob, json, hashlib, base64, urllib.parse

def read_dev_file(file):
    data = None
    try:
        with open(file, "r") as f:
            data = f.read()
        data = data.strip()
        if data == "":
            data = None
    except:
        pass
    return data

def dirname(path, n=1):
    for i in range(n):
        path = os.path.dirname(path)
    return path

usb_serial_vars = ["idProduct", "idVendor", "product", "serial", "manufacturer"]

def usb_serial_loader(dev):
    dev = os.path.realpath(dev)
    usb_dev = dirname(dev, 4)
    device_vars = {}
    device_vars["type"] = "usb"
    for var in usb_serial_vars:
        device_vars[var] = read_dev_file(os.path.join(usb_dev, var))
    if "idProduct" in device_vars and "idVendor" in device_vars:
        device_vars["devid"] = f"{device_vars["idProduct"]}:{device_vars["idVendor"]}"
    del device_vars["idProduct"]
    del device_vars["idVendor"]
    return device_vars

serial_base_vars = ["port"]

def serial_base_loader(dev):
    dev = os.path.realpath(dev)
    device_vars = {}
    device_vars["type"] = "internal"
    device_vars["name"] = os.path.basename(dev)
    for var in serial_base_vars:
        device_vars[var] = read_dev_file(os.path.join(dev, var))
    return device_vars


def load_dev_id(dev):
    return read_dev_file(os.path.join(dev, "dev"))

param_loaders = {
    "/sys/bus/usb-serial": usb_serial_loader,
    "/sys/bus/serial-base": serial_base_loader,
    "/sys/bus/usb": usb_serial_loader,
}



base_dir = "/sys/class/tty"
base_dev_dir = "/dev"

def devices_match(s, block):
    if block and stat.S_ISBLK(s.st_mode):
        return True
    if not block and stat.S_ISCHR(s.st_mode):
        return True
    return False

def list_devices(block = False):
    for dev in glob.glob(base_dev_dir + '/**', recursive=True):
        try:
            s = os.stat(dev)
        except:
            continue
        if not devices_match(s, block):
            continue
        major = os.major(s.st_rdev)
        minor = os.minor(s.st_rdev)
        yield dev, f"{major}:{minor}"

def list_serial_devices():
    devices = {}
    for d in os.listdir(base_dir):
        dev = os.path.join(base_dir, d)
        subsystem_path = os.path.join(dev, "device/subsystem")
        
        if not os.path.islink(subsystem_path):
            continue
        
        subsystem = os.path.realpath(subsystem_path)
        dev_id = load_dev_id(dev)
        if dev_id is None:
            continue

        loader = param_loaders[subsystem] if subsystem in param_loaders else None

        if loader is None:
            continue

        params = loader(dev)

        data = {"type": "serial", "dev": None, "dev_id": dev_id, "sys": dev, "params": params, "id": None, "idquery": None, "query": None}

        devices[dev_id] = data

    for dev, dev_id in list_devices(False):
        if dev_id in devices:
            if devices[dev_id]["dev"] is None or devices[dev_id]["dev"].count("/") > dev.count("/"):
                devices[dev_id]["dev"] = dev

    final_devices = []
    for record in devices.values():
        if record["dev"] is not None:
            final_devices.append(record)

    return final_devices
 

def calculate_id(dev):
    sdev = [dev["type"]]
    for key in sorted(dev['params'].keys()):
        sdev.append(key)
        sdev.append(dev['params'][key])
    sdev = json.dumps(sdev, indent=None, separators=(",",":"))
    h = hashlib.new('sha256')
    h.update(sdev.encode())
    idhash = h.digest()
    id = None
    for i in range(4):
        part = idhash[i*8:i*8+8]
        if id is None:
            id = part
        else:
            id = bytes(a ^ b for (a, b) in zip(id, part))
    return base64.urlsafe_b64encode(id).decode().rstrip("=")

def encode_params(params):
    string = ""
    for key, value in params.items():
        if value is not None:
            if string != '':
                string += "&"
            string += "{}={}".format(urllib.parse.quote_plus(key), urllib.parse.quote_plus(value))
    return string

def list_all_devices():
    all_devices = list_serial_devices()
    ids = {}
    for i, dev in enumerate(all_devices):
        id = calculate_id(dev)
        if id is not None:
            if id not in ids:
                ids[id] = i
            else:
                ids[id] = None
    for id, i in ids.items():
        if i is not None:
            all_devices[i]["id"] = id
    for dev in all_devices:
        if dev['id'] is not None:
            dev['idquery'] = '?id=' + urllib.parse.quote_plus(dev['id'])
        if len(dev['params']) != 0:
            dev['query'] = "?" + encode_params(dev["params"])
        else:
            dev['query'] = None

    return all_devices
