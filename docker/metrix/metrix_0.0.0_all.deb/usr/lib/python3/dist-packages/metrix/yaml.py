import yaml, os

def env_tag(loader, node):
    if not isinstance(node.value, str):
        raise Exception("!env tag must be used only to tag strings meaning string will be a variable name")
    return os.environ.get(node.value)

yaml.SafeLoader.add_constructor('!env', env_tag)

def safe_load(stream):
    data = yaml.safe_load(stream)
    return data
