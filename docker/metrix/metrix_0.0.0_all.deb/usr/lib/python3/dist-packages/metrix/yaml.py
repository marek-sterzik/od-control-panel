import yaml, os, json
from .process_arguments import arg_from_json

def get_string(tag_name, loader, node, allow_none = False):
    if isinstance(node, yaml.ScalarNode):
        data = loader.construct_scalar(node)
    elif isinstance(node, yaml.SequenceNode):
        data = loader.construct_sequence(node)
    else:
        raise Exception("abc")
    if allow_none and data is None:
        return data
    if isinstance(data, str):
        return data
    if isinstance(data, list) and len(data) == 1:
        if allow_none and data[0] is None:
            return data[0]
        if isinstance(data[0], str):
            return data[0]
    raise Exception(f"{tag_name} tag must be used to tag strings (or tag single element arrays with strings as the element)")
    

def safe_load(stream):
    data = yaml.safe_load(stream)
    return data

def env_tag(loader, node):
    data = get_string("!env", loader, node)
    return os.environ.get(node.value)

def file_tag(loader, node):
    data = get_string("!file", loader, node, True)
    if os.path.exists(data):
        return data
    else:
        return None

def json_tag(loader, node):
    data = get_string("!json", loader, node)
    return json.loads(data)

def safejson_tag(loader, node):
    data = get_string("!safejson", loader, node)
    return arg_from_json(data)
    
def yaml_tag(loader, node):
    data = get_string("!yaml", loader, node)
    return safe_load(data)

yaml.SafeLoader.add_constructor('!file', file_tag)
yaml.SafeLoader.add_constructor('!json', json_tag)
yaml.SafeLoader.add_constructor('!safejson', safejson_tag)
yaml.SafeLoader.add_constructor('!yaml', yaml_tag)
yaml.SafeLoader.add_constructor('!env', env_tag)
