import subprocess, json, sys, os, asyncio, re

def append(command, *args):
    for arg in args:
        command.append(arg)

def get_full_binary_name():
    return os.path.realpath(sys.argv[0])

def create_bin():
    command = []
    binary = get_full_binary_name()
    
    exe = None

    if sys.platform == 'win32':
        if re.match(r"\.exe$", binary):
            exe = binary
        else:
            exe = binary + '.exe'
        if not os.path.exists(exe):
            exe = None

    if exe is not None:
        append(command, exe)
    else:
        append(command, sys.executable, binary)

    return command

def create_command(pid, module, args, url, libs):
    command = create_bin()
    append(command, "-u", url)
    for lib in libs:
        append(command, "-l", lib)
    append(command, "client", "-p", pid, "--", module)
    for arg in args:
        append(command, json.dumps(arg))
    return command

def process_start(pid, module, args, url, libs):
    command = create_command(pid, module, args, url, libs)
    try:
        return subprocess.Popen(command, stdin=subprocess.DEVNULL, bufsize=0)
    except Exception as e:
        return None


async def process_wait(handles):
    while True:
        for handle in handles:
            if handle.poll() is not None:
                return handle
        await asyncio.sleep(1)
            
