from .attrdict import attrdict
from .process_state import process_state

server_state = attrdict()

class ServerState:
    def __init__(self, code):
        self.code = code

    def is_quitting(self):
        return self is server_state.QUITTING

    def is_terminating(self):
        return self in (server_state.TERMINATING, server_state.TERMINATED)

    def invoke_transition(self, pstate, processes_running, server):
        next_state = self.get_next_state(pstate, processes_running, server.persist)
        if next_state != self:
            next_state.transit_to(server, self)
        return next_state

    def transit_to_quit(self, server):
        next_state = server_state.QUITTING if self in (server_state.STARTING, server_state.RUNNING) else self
        if next_state != self:
            next_state.transit_to(server, self)
        return next_state

    def transit_to_terminate(self, server):
        next_state = server_state.TERMINATING if self is not server_state.TERMINATED else self
        if next_state != self:
            next_state.transit_to(server, self)
        return next_state
        

    def get_next_state(self, pstate, processes_running, persist):
        if (not persist or self is server_state.QUITTING) and pstate == process_state.TERMINATED and not processes_running:
            return server_state.TERMINATING
        if self is server_state.STARTING:
            return server_state.RUNNING
        return self

    def transit_to(self, server, previous_state):
        if self is server_state.TERMINATING:
            server.terminate_signal()
        elif self is server_state.QUITTING:
            server.quit_signal()



server_state["STARTING"] = ServerState("starting")
server_state["RUNNING"] = ServerState("running")
server_state["QUITTING"] = ServerState("quitting")
server_state["TERMINATING"] = ServerState("terminating")
server_state["TERMINATED"] = ServerState("terminated")

