def metrix_plugin(plugin):
    timer_topic = plugin.arg("timer_topic", "_timer")
    plugin.trigger([{"topic": timer_topic, "msg_types": "write"}], "metrix.proc.timer", [{"control_topic": timer_topic}])


