import asyncio

class ExpectMessage:
    def __init__(self, client, match, block_nonmatching_messages = False):
        self.client = client
        self.match = match
        self.block_nonmatching_messages = block_nonmatching_messages
        self.queue = asyncio.Queue()
        self.state = 0

    def start(self):
        if self.state > 0:
            raise RuntimeError("expecting message already started")
        self.client.register_message_consumer(self._message_consumer)
        self.state = 1

    async def wait(self):
        if (self.state == 0):
            self.start()
        if self.state != 1:
            raise RuntimeError("already awaited")
        message = await self.queue.get()
        self.client.unregister_message_consumer(self._message_consumer)
        self.state = 0
        return message

    def _message_consumer(self, msg):
        if self.state == 2:
            return False
        if not self.match(msg):
            return self.block_nonmatching_messages
        self.state = 2
        self.queue.put_nowait(msg)
        return True
        
