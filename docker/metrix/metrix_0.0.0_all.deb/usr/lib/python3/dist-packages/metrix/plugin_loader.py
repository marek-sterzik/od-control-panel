import importlib
from .message_type import message_type
from .message import message
from .schema import check
from .logger import logger

def find_plugin_loader(plugin_name):
    try:
        module = importlib.import_module(plugin_name)
    except:
        raise Exception(f"{plugin_name} is not a valid plugin (not a module)")
    if hasattr(module, "metrix_plugin"):
        return module.metrix_plugin
    raise Exception(f"{plugin_name} is not a valid plugin (does not contain function metrix_plugin)")

class MessageBag:
    def __init__(self):
        self.messages = []

    def put(self, message):
        self.messages.append(message)

class Plugin:
    def __init__(self, name, args, msg_bag):
        self._name = name
        self._args = args
        self._msg_bag = msg_bag

        loader = find_plugin_loader(self._name)
        loader(self)

    def depends(self, plugin, args={}, publish_args=False):
        inherit_args = self._args if publish_args else {}
        plugin_args = {**inherit_args, **args}
        return Plugin(plugin, plugin_args, self._msg_bag)

    def arg(self, name, default, validator=object):
        if name not in self._args:
            return default
        value = self._args[name]
        if check(validator, value):
            return value
        logger(f"invalid argument '{name}' for plugin '{self._name}', falling back to default", lev=logger.WARN)
        return default

    def start(self, module_name, args = [], pid = None, libs = []):
        self.send(message_type.CORE, "start", {"module": module_name, "args": args, "pid": pid, "libs": libs})
        return self

    def trigger(self, topics, module_name, args=[], id = None, libs = []):
        self.send(message_type.CORE, "trigger", {"topics": topics, "module": module_name, "args": args, "id": id, "libs": libs})
        return self

    def plugins(self, plugins, libs = [], reference = None):
        self.send(message_type.CORE, "plugins", {"plugins": plugins, "libs": libs}, reference)
        return self

    def broadcast(self, topic, payload, reference = None):
        self.send(message_type.BROADCAST, topic, payload, reference = reference)
        return self

    def query(self, topic, payload = None, reference = None):
        self.send(message_type.QUERY, topic, payload, reference = reference)
        return self

    def message(self, topic, payload, reference = None):
        self.send(message_type.MESSAGE, topic, payload, reference = reference)
        return self

    def write(self, topic, payload, reference = None):
        self.send(message_type.WRITE, topic, payload, reference = reference)
        return self

    def error(self, topic, payload, reference = None):
        self.send(message_type.ERROR, topic, payload, reference = reference)
        return self

    def send(self, msg_type, topic, payload = None, reference = None):
        self.put_message(message(msg_type, topic, payload, reference))
        return self

    def put_message(self, message):
        self._msg_bag.put(message)
        return self


def load_plugin(name, args = {}):
    msg_bag = MessageBag()
    Plugin(name, args, msg_bag)
    return msg_bag.messages
