from .attrdict import attrdict
from .schema import validate

def compose(a, b):
    return lambda x: b(a(x))

def seq_var_type(*types):
    fn = None
    for var_type in types:
        if (fn is None):
            fn = var_type
        else:
            fn = compose(fn, var_type)
    if fn is None:
        return lambda x: x
    else:
        return fn

def interval(a, b, include_boundary, x):
    if include_boundary:
        if ((a is not None) and (x < a)) or ((b is not None) and (x > b)):
            a = a if a is not None else "∞"
            b = b if b is not None else "∞"
            raise Exception(f"number {x} out of range [{a}, {b}]")
    else:
        if ((a is not None) and (x <= a)) or ((b is not None) and (x >= b)):
            a = a if a is not None else "∞"
            b = b if b is not None else "∞"
            raise Exception(f"number {x} out of range ({a}, {b})")

def choices(choices, x):
    if x not in choices:
        raise Exception("'{}' must be one of: {}".format(x, ", ".join(map(lambda x: f"'{x}'",choices))))

var_types = attrdict()
var_types["str"] = lambda x: x
var_types["int"] = lambda x: int(x)
var_types["float"] = lambda x: float(x)
var_types["choices"] = lambda *ch: lambda x: choices(ch, x)
var_types["validator"] = lambda schema: lambda x: validate(schema, x)
var_types["sequence"] = seq_var_type
var_types["interval"] = lambda a, b, include_boundary = True: lambda x: interval(a, b, include_boundary, x)

