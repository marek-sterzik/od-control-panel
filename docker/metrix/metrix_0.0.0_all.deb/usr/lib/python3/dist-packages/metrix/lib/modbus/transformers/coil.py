from .abstract import AbstractTransformer
from ..operations import operations
from schema import Optional, And, Or
from metrix.schema import validation, check

class CoilTransformer(AbstractTransformer):
    def __init__(self, config={}):
        self.count = config["count"] if "count" in config else None

    def get_read_operation(self):
        if self.count is None:
            return operations.read_coil()
        else:
            return operations.read_coil_multi(count)

    def get_write_operation(self, value):
        if self.count is None:
            return operations.write_coil(value)
        else:
            if not check([object], value):
                raise Exception("written value is not an array")
            if len(value) != self.count:
                raise Exception("written value array has invalid length")
            return operations.write_coil_multi(value)

    validation = {Optional("count"): Or(None, And(int, validation.range(0, 65535)))}
