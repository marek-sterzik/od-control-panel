import os, re, shutil
from string import Template
from pprint import pprint

TEMPLATES_ROOT = os.path.join(os.path.dirname(__file__), "templates")

def lookahead(iterable):
    it = iter(iterable)
    try:
        last = next(it)
    except StopIteration:
        return
    for val in it:
        yield last, True
        last = val
    yield last, False

class Item:
    def __init__(self, name):
        if name == "" or re.search(r"[/\x00]", name):
            raise Exception(f"invalid directory record name: '{name}'")
        self.name = name
        self.parent = None
        self.children = {}

    def _add_subitem(self, item):
        name = item.name
        if name in self.children:
            raise Exception(f"file already exists: {name}")
        self.children[name] = item
        item.parent = self
        return item

    def path(self):
        if self.parent is not None:
            parent_path = self.parent.path()
            if parent_path == ".":
                return self.name
            else:
                return os.path.join(self.parent.path(), self.name)
        else:
            return "."

    def __iter__(self):
        children = list(self.children.keys())
        children.sort()
        for child in children:
            yield self.children[child]

    def tree(self, prefix = "", var1_prefix="", var2_prefix=""):
        tree = f"{prefix}{var1_prefix}{self.name}\n"
        subprefix = f"{prefix}{var2_prefix}"
        for file, has_more in lookahead(self):
            if has_more:
                var1_prefix = " ├─ "
                var2_prefix = " │  "
            else:
                var1_prefix = " └─ "
                var2_prefix = "    "
            tree += file.tree(subprefix, var1_prefix, var2_prefix)
        return tree
        

class InputItem(Item):
    def interpret(self, variables):
        output = self.interpret_self(variables)
        for file in self:
            output._add_subitem(file.interpret(variables))
        return output

    def get_output_params(self):
        raise Exception("this is an abstract method")

    def interpret_self(self, variables):
        interpreted_name = self.name.format(**variables)
        output_class, tpl_lookup = self.get_output_params()
        interpret = False
        if tpl_lookup and re.search(r"\.tpl$", interpreted_name):
            interpreted_name = re.sub(r"\.tpl$", '', interpreted_name)
            interpret = True

        output = output_class(interpreted_name)
        output.setup(variables, interpret, self.path())
        return output

class InputDirectory(InputItem):
    def add_subdir(self, name):
        return self._add_subitem(InputDirectory(name))
    
    def add_file(self, name):
        return self._add_subitem(InputFile(name))

    def load_from_path(self, path):
        if not os.path.isdir(path):
            raise Exception(f"trying to load a non-directory as a directory: {path}")
        for file in os.listdir(path):
            if file in [".", ".."]:
                continue
            file_path = os.path.join(path, file)
            if os.path.isdir(file_path):
                directory = self.add_subdir(file)
                directory.load_from_path(file_path)
            elif os.path.isfile(file_path):
                self.add_file(file)
    def get_output_params(self):
        return OutputDirectory, False
                


class InputFile(InputItem):
    def get_output_params(self):
        return OutputFile, True

class OutputItem(Item):
    def setup(self, variables, interpret, source_path):
        self.variables = variables
        self.interpret = interpret
        self.source_path = source_path

    def write(self, src, dst):
        self.write_self(os.path.join(src, self.source_path), os.path.join(dst, self.path()))
        for file in self:
            file.write(src, dst)

    def write_self(self, src, dst):
        raise Exception("this is an abstract method")

class OutputDirectory(OutputItem):
    def write_self(self, src, dst):
        if self.path() != '.':
            os.mkdir(dst)

class OutputFile(OutputItem):
    def write_self(self, src, dst):
        if self.interpret:
            self.interpret_template(src, dst)
        else:
            self.copy(src, dst)
        self.setup_permissions(src, dst)

    def interpret_template(self, src, dst):
        with open(src) as f:
            content = f.read()
        content = Template(content).safe_substitute(self.variables)
        with open(dst, "w") as f:
            f.write(content)

    def copy(self, src, dst):
        shutil.copy(src, dst)

    def setup_permissions(self, src, dst):
        if os.access(src, os.X_OK):
            os.chmod(dst, 0o755)
        else:
            os.chmod(dst, 0o644)

class ProjectTemplateInstance:
    def __init__(self, template, variables):
        self.template = template
        self.variables = variables

    def populate_directory(self, directory, force):
        if os.path.exists(directory):
            if not os.path.isdir(directory):
                raise Exception(f"file already exists: {directory}")
            if os.listdir(directory) and not force:
                raise Exception(f"project directory is not empty, use --force to force override")
            shutil.rmtree(directory)
        else:
            base_dir = os.path.dirname(directory)
            if base_dir == "":
                base_dir = "."
            if not os.path.isdir(base_dir):
                raise Exception("project directory must be created inside another existing directory")
        os.mkdir(directory)
        if not os.path.isdir(directory):
            raise Exception(f"cannot create directory: {directory}")
        return self.populate_files(directory)

    def populate_files(self, directory):
        input_directory = InputDirectory(os.path.basename(directory))
        template_dir = os.path.join(TEMPLATES_ROOT, self.template.name())
        input_directory.load_from_path(template_dir)
        output_directory = input_directory.interpret(self.variables)
        output_directory.write(template_dir, directory)
        return output_directory

    templates_root = TEMPLATES_ROOT
    
