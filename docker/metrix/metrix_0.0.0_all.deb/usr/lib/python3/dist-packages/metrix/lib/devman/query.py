import urllib.parse
from .cache import list_devices_cached

meta_keys = ["id"]

def parse_query_vars(query, device_class):
    query_vars = urllib.parse.parse_qs(query)
    if device_class != "all" and not (isinstance(device_class, list) and "all" in device_class):
        if ":type" not in query_vars:
            query_vars[":type"] = []
        query_vars[":type"].append(device_class)
    for key in meta_keys:
        if key in query_vars:
            mkey = ":" + key
            if mkey not in query_vars:
                query_vars[mkey] = []
            for val in query_vars[key]:
                query_vars[mkey].append(val)
            del query_vars[key]
    return query_vars

def match_string(string, pattern):
    if isinstance(pattern, list):
        for p in pattern:
            if match_string(string, p):
                return True
        return False
    elif isinstance(pattern, str):
        return string == pattern
    else:
        return False

def match_device(device, query_vars):
    for key, values in query_vars.items():
        for value in values:
            if key[0:1] == ":":
                key = key[1:]
                if key == "params":
                    return False
                if (key not in device) or not match_string(device[key], value):
                    return False
            else:
                if (key not in device["params"]) or not match_string(device["params"][key], value):
                    return False
    return True

def query_devices(query, device_class, force_refetch = False):
    query_vars = parse_query_vars(query, device_class)
    cache = list_devices_cached(force_refetch)
    devices = list(filter(lambda dev: match_device(dev, query_vars), cache["devices"]))
    return devices

def query_device(query, device_class, force_refetch = False):
    query_vars = parse_query_vars(query, device_class)
    cache = list_devices_cached(force_refetch)
    devices = list(filter(lambda dev: match_device(dev, query_vars), cache["devices"]))
    if len(devices) == 1:
        return devices[0]
    if not cache["fetched"]:
        cache = list_devices_cached(True)
        devices = list(filter(lambda dev: match_device(dev, query_vars), cache["devices"]))
        if len(devices) == 1:
            return devices[0]

    if len(devices) == 0:
        raise Exception(f"no device found: ?{query}")
    else:
        raise Exception(f"ambigous device, multiple devices found: ?{query}")
