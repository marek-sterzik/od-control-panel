import sys, os, asyncio, curses
from datetime import datetime
from metrix import client, message_type, logger, validation

# Sentinel for "never received a message yet" (distinct from a null payload)
_NOT_RECEIVED = object()

_state = {}

def is_terminal():
    try:
        if not os.isatty(0) or not os.isatty(1) or not os.isatty(2):
            return False
    except:
        return False
    return True

def metrix_recv(msg):
    if msg.msg_type == message_type.BROADCAST:
        _state[msg.topic] = {"value": msg.payload, "updated": datetime.now()}


async def metrix_async_process():
    if client.pid is not None:
        logger("monitor cannot be started as a metrix process, terminating",lev = logger.ERR)
        return 1
    if not is_terminal():
        print("Error: cannot start monitor not being on a terminal", file = sys.stderr)
        return 1

    topic = client.get_config("publisher_topic", "_publisher", validation.topic)
    client.publisher.set_publisher(topic)
    client.publisher.consume()
    stdscr = curses.initscr()
    curses.noecho()
    curses.cbreak()
    stdscr.keypad(True)
    stdscr.nodelay(True)

    try:
        while True:
            ch = stdscr.getch()
            if ch in (ord("q"), ord("Q")):
                break

            stdscr.erase()
            stdscr.addstr(0, 0, "Metrix Monitor  [q] quit")
            stdscr.addstr(1, 0, "-" * 60)
            row = 2
            for item in client.publisher.values:
                topic = item["topic"]
                data = _state[topic] if topic in _state else {"value": _NOT_RECEIVED, "updated": None}
                val_str = str(data["value"]) if data["value"] is not _NOT_RECEIVED else "..."
                ts_str = (
                    data["updated"].strftime("%H:%M:%S")
                    if data["updated"] is not None
                    else "never"
                )
                line = f"{topic:<35} {val_str:<20} {ts_str}"
                stdscr.addstr(row, 0, line)
                row += 1
            stdscr.refresh()

            await asyncio.sleep(0.1)

    except (KeyboardInterrupt, asyncio.CancelledError):
        pass

    finally:
        curses.nocbreak()
        stdscr.keypad(False)
        curses.echo()
        curses.endwin()
