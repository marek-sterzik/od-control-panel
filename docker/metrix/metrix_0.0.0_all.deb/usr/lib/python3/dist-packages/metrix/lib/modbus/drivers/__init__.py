from metrix.attrdict import attrdict
from metrix.schema import validation
from .dummy import ModbusDummyDriver
from .serial import PyModbusSerialDriver

drivers = attrdict()

drivers["dummy"] = ModbusDummyDriver
drivers["serial"] = PyModbusSerialDriver

def instantiate_driver(config):
    modbus_driver_type = config['type']
    if modbus_driver_type not in drivers:
        raise Exception(f"modbus driver not available: {config['type']}")
    
    return getattr(drivers, modbus_driver_type)(config)
    

driver_variants = {}
for driver_name, driver in drivers.items():
    driver_variants[driver_name] = driver.validation

def config_validation(ignored_keys = []):
    return validation.polymorphic("type", driver_variants, ignored_keys = ignored_keys)
