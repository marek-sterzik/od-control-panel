import os

webdir = os.path.realpath(os.path.join(os.path.dirname(__file__), "web"))
