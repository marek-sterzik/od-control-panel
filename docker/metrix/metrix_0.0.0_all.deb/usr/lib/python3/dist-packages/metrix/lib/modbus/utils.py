def default(data, key, dflt):
    return data[key] if (key in data) and data[key] is not None else dflt

