const HardwareApp = {
    digits: {
        '0': '1111110', '1': '0110000', '2': '1101101', '3': '1111001', '4': '0110011',
        '5': '1011011', '6': '1011111', '7': '1110000', '8': '1111111', '9': '1111011', 'off': '0000000'
    },

    init() {
        this.setupTooltips();
        this.setupHardwareSync();
    },

    setupTooltips() {
        const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
        [...tooltipTriggerList].map(t => new bootstrap.Tooltip(t));
    },

    setupHardwareSync() {
        document.querySelectorAll('.bulb-checkbox').forEach(box => {
            box.addEventListener('change', () => this.syncState());
        });

        const segments = document.querySelectorAll('.segment-widget');
        segments.forEach(widget => this.initSegment(widget));

        const setBtn = document.getElementById('setDisplayBtn');
        const resetBtn = document.getElementById('resetDisplayBtn');
        const input = document.getElementById('displayInput');
        
        if (setBtn && input && segments.length >= 2) {
            setBtn.addEventListener('click', () => {
                let val = input.value.trim().padStart(2, '0').slice(-2);
                if (!val || val === '00' && input.value.trim() === '') return;

                const dot1 = segments[0].querySelector('.state-input').value[7] || '0';
                const dot2 = segments[1].querySelector('.state-input').value[7] || '0';

                this.renderSegment(segments[0], this.digits[val[0]] + dot1, false);
                this.renderSegment(segments[1], this.digits[val[1]] + dot2, true);
                input.value = '';
            });
            input.addEventListener('keypress', e => { if (e.key === 'Enter') setBtn.click(); });
        }

        if (resetBtn && segments.length >= 2) {
            resetBtn.addEventListener('click', () => {
                this.renderSegment(segments[0], '00000000', false);
                this.renderSegment(segments[1], '00000000', true);
            });
        }
    },

    initSegment(widget) {
        const display = widget.querySelector('.seven-segment');
        const input = widget.querySelector('.state-input');
        const segs = display.querySelectorAll('.seg');

        this.renderSegment(widget, display.getAttribute('data-state'), false);

        segs.forEach(seg => {
            seg.addEventListener('click', e => {
                const idx = parseInt(e.target.getAttribute('data-idx'), 10);
                const arr = input.value.split('');
                arr[idx] = arr[idx] === '1' ? '0' : '1';
                this.renderSegment(widget, arr.join(''), true);
            });
        });
    },

    renderSegment(widget, stateStr, save = false) {
        if(!stateStr || stateStr.length !== 8) return;
        widget.querySelectorAll('.seg').forEach((seg, i) => {
            if (stateStr[i]) seg.classList.toggle('active', stateStr[i] === '1');
        });
        widget.querySelector('.state-input').value = stateStr;
        if (save) this.syncState();
    },

    async syncState() {
        const data = Array.from(document.querySelectorAll('.control-item')).map(item => {
            const type = item.dataset.type;
            const input = item.querySelector('.state-input');
            return {
                id: item.dataset.id,
                type: type,
                caption: item.dataset.caption || "",
                state: type === 'switch' ? input.checked : parseInt(input.value, 10)
            };
        });

        const payload = { template: "controlapp/controls.html.twig", vars: { logoutUrl: "{{ logoutUrl|default('login') }}", controls: data } };

        try {
            const res = await fetch(window.location.href, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload, null, 4)
            });
            
            if (res.ok && window.showNotification) {
                window.showNotification('<i class="bi bi-cloud-check-fill me-2"></i> Úspěšně uloženo');
            }
        } catch (e) { console.error('Network Error:', e); }
    }
};

document.addEventListener('DOMContentLoaded', () => HardwareApp.init());